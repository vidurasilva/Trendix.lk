<?php

if (!defined('_PS_VERSION_')) exit;

include_once(dirname(__FILE__) . '/tspproducttabssliderclass.php');

class TSPProductTabsSlider extends TSPProductTabsSliderClass {

	public function __construct()
	{
		$this->name = 'tspproducttabsslider';
		$this->tab = 'front_office_features';
		$this->version = '1.0.0';
		$this->author = 'TPL Solution';
		$this->need_instance = 0;
		$this->ps_versions_compliancy = array('min' => '1.6', 'max' => '1.6');
		$this->bootstrap = true;
		$this->_directory = dirname(__FILE__);

		parent::__construct();

		$this->displayName = $this->l('TSP Product Tabs Slider');
		$this->description = $this->l('This is module display product on tab with slider.');

		$this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
	}

	public function install()
	{
		$this->_clearCache('*');
		
		if (!parent::install()
			|| !$this->registerHook('actionOrderStatusPostUpdate')
			|| !$this->registerHook('addproduct')
			|| !$this->registerHook('updateproduct')
			|| !$this->registerHook('deleteproduct')
			|| !$this->registerHook('displayTSPProductTabsSlider')
		)
			return false;

		$this->updateValue('TSPTS_TITLE', 'TSP Product Tabs Slider|Placement subtitles', true);
		$this->updateValue('TSPTS_NUMDISPLAY', 6);
		$this->updateValue('TSPTS_XS', 2);
		$this->updateValue('TSPTS_SM', 2);
		$this->updateValue('TSPTS_MD', 3);
		$this->updateValue('TSPTS_LG', 4);
		$this->updateValue('TSPTS_PRDIDS', '');
		$this->updateValue('TSPTS_ORDERBY', 'name');
		$this->updateValue('TSPTS_ORDERWAY', 'ASC');
		
		$this->updateValue('TSPTS_CATEGORY_TABS_ID', 'special_product,new_product,top_sellers');

		$this->installFixtures();

		$this->tspCreateTab();

		return true;
	}

	protected function installFixtures()
	{
		$languages = Language::getLanguages(false);
		foreach ($languages as $lang)
			$this->installFixture((int)$lang['id_lang']);
		return true;
	}

	protected function installFixture($id_lang)
	{
		$val = array();
		$values['TSPTS_TITLE'][(int)$id_lang] = 'TSP Product Tabs Slider';
		$this->updateValue('TSPTS_TITLE', $values['TSPTS_TITLE'], true);
	}
	public function uninstall()
	{
		Configuration::deleteByName('TSPTS_TITLE');
		Configuration::deleteByName('TSPTS_NUMDISPLAY');
		Configuration::deleteByName('TSPTS_XS');
		Configuration::deleteByName('TSPTS_SM');
		Configuration::deleteByName('TSPTS_MD');
		Configuration::deleteByName('TSPTS_LG');
		Configuration::deleteByName('TSPTS_PRDIDS');
		Configuration::deleteByName('TSPTS_ORDERBY');
		Configuration::deleteByName('TSPTS_ORDERWAY');
		Configuration::deleteByName('TSPTS_CATEGORY_TABS_ID');

		$this->tspDeleteTab();
		return parent::uninstall();
	}

	public function getConfigFieldsValues() {
		$values = array();
		
		$languages = Language::getLanguages(false);
		
		foreach ($languages as $lang) {
			$values['TSPTS_TITLE'][$lang['id_lang']] = Tools::getValue('TSPTS_TITLE_'.$lang['id_lang'], Configuration::get('TSPTS_TITLE', $lang['id_lang']));
		}

		$values['TSPTS_NUMDISPLAY'] = Configuration::get('TSPTS_NUMDISPLAY');
		$values['TSPTS_PRDIDS'] = Configuration::get('TSPTS_PRDIDS');
		$values['TSPTS_ORDERBY'] = Configuration::get('TSPTS_ORDERBY');
		$values['TSPTS_ORDERWAY'] = Configuration::get('TSPTS_ORDERWAY');
		$values['TSPTS_XS'] = Configuration::get('TSPTS_XS');
		$values['TSPTS_SM'] = Configuration::get('TSPTS_SM');
		$values['TSPTS_MD'] = Configuration::get('TSPTS_MD');
		$values['TSPTS_LG'] = Configuration::get('TSPTS_LG');

		return $values;
	}

	public function getContent()
	{
		$this->context->controller->addjQueryPlugin(array('tagify'));
		$languages = Language::getLanguages(false);
		$output = '';
		if (Tools::isSubmit('submitTSPProductTabsSlider'))
		{
			if (!Tools::getValue('TSPTS_NUMDISPLAY') || Tools::getValue('TSPTS_NUMDISPLAY') <= 0 || !Validate::isInt(Tools::getValue('TSPTS_NUMDISPLAY')))
				$errors[] = $this->l('Invalid number of products');
			
			if (!Tools::getValue('TSPTS_XS')  || !Validate::isInt(Tools::getValue('TSPTS_XS')) )
				$errors[] = $this->l('Invalid number pre row.');
			if (!Tools::getValue('TSPTS_SM')  || !Validate::isInt(Tools::getValue('TSPTS_SM')) )
				$errors[] = $this->l('Invalid number pre row.');
			if (!Tools::getValue('TSPTS_MD')  || !Validate::isInt(Tools::getValue('TSPTS_MD')) )
				$errors[] = $this->l('Invalid number pre row.');
			if (!Tools::getValue('TSPTS_LG')  || !Validate::isInt(Tools::getValue('TSPTS_LG')) )
				$errors[] = $this->l('Invalid number pre row.');
			
			$items = Tools::getValue('items');
			if (!(is_array($items) && count($items) && $this->updateValue('TSPTS_CATEGORY_TABS_ID', (string)implode(',', $items))))
				$errors[] =$this->l('Unable to update settings.');

			if (isset($errors) AND sizeof($errors)) {
				$output .= $this->displayError(implode('<br />', $errors));
			} else {
				$values = array();
				foreach ($languages as $lang) {
					$values['TSPTS_TITLE'][$lang['id_lang']] = Tools::getValue('TSPTS_TITLE_'.$lang['id_lang']);
				}
				$this->updateValue('TSPTS_TITLE', $values['TSPTS_TITLE'], true);

				$prd_ids = Tools::getValue('TSPTS_PRDIDS');
				$prd_ids_arr = explode(',', $prd_ids);
				foreach ($prd_ids_arr as $k => &$prd_id) {
					$prd_id = (int)$prd_id;
					if(!$prd_id || $prd_id < 0) unset($prd_ids_arr[$k]);
				}
				$prd_ids = implode(',', array_unique($prd_ids_arr));
				
				$this->updateValue('TSPTS_PRDIDS', $prd_ids);
				$this->updateValue('TSPTS_ORDERBY', Tools::getValue('TSPTS_ORDERBY'));
				$this->updateValue('TSPTS_ORDERWAY', Tools::getValue('TSPTS_ORDERWAY'));
				$this->updateValue('TSPTS_NUMDISPLAY', (int)Tools::getValue('TSPTS_NUMDISPLAY'));
				$this->updateValue('TSPTS_XS', (int)Tools::getValue('TSPTS_XS'));
				$this->updateValue('TSPTS_SM', (int)Tools::getValue('TSPTS_SM'));
				$this->updateValue('TSPTS_MD', (int)Tools::getValue('TSPTS_MD'));
				$this->updateValue('TSPTS_LG', (int)Tools::getValue('TSPTS_LG'));
				
				$output .= $this->displayConfirmation($this->l('Settings updated'));
			}
			$this->_clearCache("*");
		}
		$output .= $this->getFormHTML();
		return $output;
	}
	public function getFormHTML()
	{
		$helper = new HelperForm();
		$helper->show_toolbar = false;
		$helper->table = $this->table;
		$lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
		$helper->default_form_language = $lang->id;
		$helper->module = $this;
		$helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
		$helper->identifier = $this->identifier;
		$helper->submit_action = 'submitTSPProductTabsSlider';
		$helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
									.'&configure='.$this->name
									.'&tab_module='.$this->tab
									.'&module_name='.$this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->tpl_vars = array(
			'uri' => $this->getPathUri(),
			'fields_value' => $this->getConfigFieldsValues(),
			'languages' => $this->context->controller->getLanguages(),
			'id_language' => $this->context->language->id,
			'choices' => $this->renderChoicesSelect(),
			'selected_links' => $this->makeMenuOption()
		);

		$fields_form = array();
		$fields_form[0] = array(
            array(
                'type' => 'text',
                'label' => $this->l('Module Title'),
                'name' => 'TSPTS_TITLE',
                'class' => 'fixed-width-xl',
            	'lang' => true
            ),
			array(
				'type' => 'text',
				'label' => $this->l('Max. product count per tab'),
				'name' => 'TSPTS_NUMDISPLAY',
				'class' => 'fixed-width-xs',
				'suffix' => $this->l('products per tab')
			),
			array(
				'type' => 'link_choice',
				'label' => '',
				'name' => 'link',
				'lang' => true,
			),	
			array(
				'type' => 'prd_ids',
				'label' => $this->l('Product ids'),
				'name' => 'TSPTS_PRDIDS',
				'hint' => $this->l('To add "Product Ids," click in the field, write product id, and then press "Enter."'),
				'desc' => $this->l('Product ids only apply for Featured Product tab.')
				),
			array(
				'type' => 'select',
				'label' => 'Order by',
				'name' => 'TSPTS_ORDERBY',
				'desc' => $this->l('This field only apply for categories.'),
				'options' => array(
					'query' => array(
									array('id' => 'name', 'name' => 'Name'),
									array('id' => 'price', 'name' => 'Price'),
									array('id' => 'date_add', 'name' => 'Date Added'),
									array('id' => 'date_upd', 'name' => 'Date Updated'),
									array('id' => 'sales', 'name' => 'Sales'),
									array('id' => 'position', 'name' => 'Position'),
									array('id' => 'id_product', 'name' => 'ID Product'),
									array('id' => 'rand', 'name' => 'Random')
								),
					'id' => 'id',
					'name' => 'name'
				)
			),
			array(
				'type' => 'select',
				'label' => 'Order way',
				'name' => 'TSPTS_ORDERWAY',
				'desc' => $this->l('This field only apply for categories.'),
				'options' => array(
					'query' => array(
								array('id' => 'ASC', 'name' => 'ASC'),
								array('id' => 'DESC', 'name' => 'DESC')
							),
					'id' => 'id',
					'name' => 'name'
				)
			),
			array(
				'label' => $this->l('Screen width > 480px'),
				'name' => 'TSPTS_XS',
				'type' => 'text', 'class' => 'fixed-width-xs', 'suffix' => $this->l('products per row')
			),
			array(
				'label' => $this->l('Screen width > 768px'),
				'name' => 'TSPTS_SM',
				'type' => 'text', 'class' => 'fixed-width-xs', 'suffix' => $this->l('products per row')
			),
			array(
				'label' => $this->l('Screen width > 992px'),
				'name' => 'TSPTS_MD',
				'type' => 'text', 'class' => 'fixed-width-xs', 'suffix' => $this->l('products per row')
			),
			array(
				'label' => $this->l('Screen width > 1200px'),
				'name' => 'TSPTS_LG',
				'type' => 'text', 'class' => 'fixed-width-xs', 'suffix' => $this->l('products per row')
			),
		);
		return $helper->generateForm(array(
			array(
				'form' => array(
					'legend' => array(
						'title' => $this->l('General Options'),
						'icon' => 'icon-cogs'
					),
					'input' => $fields_form[0],
					'submit' => array(
						'title' => $this->l('Save')
					)
				)
			)
		));
	}
	public function getConfigLang($field)
	{
		$lang = $this->context->language->id;
		if (is_bool(Configuration::get($field, $this->context->language->id)))
			$lang = Configuration::get('PS_LANG_DEFAULT');
		else
			$lang = $this->context->language->id;
		return Configuration::get($field, $lang);
	}
	public function getVarAssign() {
		$context = Context::getContext();
		$id_lang = (int) $context->language->id;
		$vars = array();
		
		$lang_fields = array('TSPTS_TITLE');
		$fields = array('TSPTS_NUMDISPLAY', 'TSPTS_NUMLOAD', 'TSPTS_EFFECT', 'TSPTS_XS', 'TSPTS_SM', 'TSPTS_MD', 'TSPTS_LG');

		foreach($fields as $field)
			$vars[$field] = Configuration::get($field);
		
		foreach($lang_fields as $field) 
		{
			if(is_bool(Configuration::get($field, $id_lang)))
				$vars[$field] = Configuration::get($field, Configuration::get('PS_LANG_DEFAULT'));
			else
				$vars[$field] = Configuration::get($field, $id_lang);
		}
		$vars['TSPTS_SUB_TITLE'] = '';
		if(isset($vars['TSPTS_TITLE']) && $vars['TSPTS_TITLE']) {
			$titles = explode('|', $vars['TSPTS_TITLE']);
			$vars['TSPTS_TITLE'] = $titles[0];
			$vars['TSPTS_SUB_TITLE'] = (isset($titles[1]) && $titles[1]) ? $titles[1] : '';
		}
		return $vars;
	}
	protected function displayTSPProductTabsSlider()
	{
		$context = Context::getContext();
		$id_lang = (int) $context->language->id;
		
		$cache_id = $this->getCacheId('tspproducttabsslider');
		if (!$this->isCached('default.tpl', $cache_id))
		{
			$tabs = $this->_getData();
			if (empty($tabs))
				return;
			$context->smarty->assign(array('tabs' => $tabs));
			$context->smarty->assign($this->getVarAssign());
			$context->smarty->assign(array('homeSize' => Image::getSize(ImageType::getFormatedName('home'))));
		}
		
		return $this->display(__FILE__, 'default.tpl', $cache_id);
	}
	public function hookDisplayTSPProductTabsSlider()
	{
		return $this->displayTSPProductTabsSlider();
	}
	public function _processAjaxCall()
	{
		$context = Context::getContext();
		$is_ajax =	Tools::getValue('is_ajax');
		$module_name = Tools::getValue('module_name');
		if($is_ajax && $module_name == $this->name ) {
			$ajax_start = Tools::getValue('ajax_start');
			$categoryid	 = Tools::getValue('categoryid');
			$data_type = Tools::getValue('data_type');
			$products = $this->_getProductInfor($categoryid,$data_type);
			
			$context->smarty->assign($this->getVarAssign());
			$context->smarty->assign(
				array(
					'ajax_start' => Tools::getValue('ajax_start'),
					'products' => $products,
					'homeSize' => Image::getSize(ImageType::getFormatedName('home'))
				)
			);
			
            $product_list = $this->display(__FILE__, 'items.tpl');
			
			//$product_list = $context->smarty->fetch(__FILE__, 'items.tpl');
			$vars = array(
				'productList' => $product_list
			);
			die( Tools::jsonEncode($vars));
		}
	}
	public function getLabelField($key){
		$name_label = '';
		switch($key){
			default:
			case 'featured_product':
				$name_label = $this->l('Featured Products');
				break;
			case 'special_product':
				$name_label = $this->l('Special Products');
				break;
			case 'new_product':
				$name_label = $this->l('New Products');
				break;
			case 'top_sellers':
				$name_label = $this->l('Best Sellers');
				break;			
		}
		return $name_label;
	}
	public function hookAddProduct($params)
	{
		$this->_clearCache('*');
	}
	public function hookUpdateProduct($params)
	{
		$this->_clearCache('*');
	}
	public function hookDeleteProduct($params)
	{
		$this->_clearCache('*');
	}
	public function hookActionOrderStatusPostUpdate($params)
	{
		$this->_clearCache('*');
	}
	public static function updateValue($key, $values, $html = false, $id_shop_group = null, $id_shop = null)
	{
		if (!Validate::isConfigName($key))
			die(sprintf(Tools::displayError('[%s] is not a valid configuration key'), $key));

		if ($id_shop === null || !Shop::isFeatureActive())
			$id_shop = Shop::getContextShopID(true);
		if ($id_shop_group === null || !Shop::isFeatureActive())
			$id_shop_group = Shop::getContextShopGroupID(true);

		if (!is_array($values))
			$values = array($values);

		if ($html)
			foreach ($values as $lang => $value)
				$values[$lang] = Tools::purifyHTML($value);

		$result = true;
		foreach ($values as $lang => $value)
		{
			$stored_value = Configuration::get($key, $lang, $id_shop_group, $id_shop);
			// if there isn't a $stored_value, we must insert $value
			if ((!is_numeric($value) && $value === $stored_value) || (is_numeric($value) && $value == $stored_value && Configuration::hasKey($key, $lang)))
				continue;

			// If key already exists, update value
			if (Configuration::hasKey($key, $lang, $id_shop_group, $id_shop))
			{
				if (!$lang)
				{
					// Update config not linked to lang
					$result &= Db::getInstance()->update('configuration', array(
						'value' => pSQL($value, $html),
						'date_upd' => date('Y-m-d H:i:s'),
					), '`name` = \''.pSQL($key).'\''.TSPProductTabsSlider::sqlRestriction($id_shop_group, $id_shop), 1, true);
				}
				else
				{
					// Update multi lang
					$sql = 'UPDATE `'._DB_PREFIX_.bqSQL('configuration').'_lang` cl
							SET cl.value = \''.pSQL($value, $html).'\',
								cl.date_upd = NOW()
							WHERE cl.id_lang = '.(int)$lang.'
								AND cl.`'.bqSQL('id_configuration').'` = (
									SELECT c.`'.bqSQL('id_configuration').'`
									FROM `'._DB_PREFIX_.bqSQL('configuration').'` c
									WHERE c.name = \''.pSQL($key).'\''
										.TSPProductTabsSlider::sqlRestriction($id_shop_group, $id_shop)
								.')';
					$result &= Db::getInstance()->execute($sql);
				}
			}
			// If key does not exists, create it
			else
			{
				if (!$configID = Configuration::getIdByName($key, $id_shop_group, $id_shop))
				{
					$newConfig = new Configuration();
					$newConfig->name = $key;
					if ($id_shop)
						$newConfig->id_shop = (int)$id_shop;
					if ($id_shop_group)
						$newConfig->id_shop_group = (int)$id_shop_group;
					if (!$lang)
						$newConfig->value = $value;
					$result &= $newConfig->add(true, true);
					$configID = $newConfig->id;
				}

				if ($lang)
				{
					$result &= Db::getInstance()->insert('configuration_lang', array(
						'id_configuration' => $configID,
						'id_lang' => (int)$lang,
						'value' => pSQL($value, $html),
						'date_upd' => date('Y-m-d H:i:s'),
					));
				}
			}
		}

		Configuration::set($key, $values, $id_shop_group, $id_shop);

		return $result;
	}
	protected static function sqlRestriction($id_shop_group, $id_shop)
	{
		if ($id_shop)
			return ' AND id_shop = '.(int)$id_shop;
		elseif ($id_shop_group)
			return ' AND id_shop_group = '.(int)$id_shop_group.' AND (id_shop IS NULL OR id_shop = 0)';
		else
			return ' AND (id_shop_group IS NULL OR id_shop_group = 0) AND (id_shop IS NULL OR id_shop = 0)';
	}
}
