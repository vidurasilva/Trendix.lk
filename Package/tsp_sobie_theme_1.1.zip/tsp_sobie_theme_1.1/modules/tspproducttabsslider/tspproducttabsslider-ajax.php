<?php

include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../init.php');
include(dirname(__FILE__).'/tspproducttabsslider.php');

$tspproduct_tabsslider = new TSPProductTabsSlider();
echo $tspproduct_tabsslider->_processAjaxCall();