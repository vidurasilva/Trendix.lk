<?php
/**
 * @package TSP TWITTER
 * @version 1.0.0
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @copyright (c) 2014 TSP Group. All Rights Reserved.
 * @author TPL Solution http://tspsolution.com
 */

if (!defined('_PS_VERSION_')) exit;

class TSPTwitter extends Module {
	protected $html = '';

	public function __construct() {
		$this->name = 'tsptwitter';
		$this->tab = 'home';
		$this->version = '1.0';
		$this->author = 'TPL Solution';
		$this->need_instance = 0;
		$this->ps_versions_compliancy = array('min' => '1.5', 'max' => '1.6');
		$this->bootstrap = true;
		$this->_directory = dirname(__FILE__);

		parent::__construct();

		$this->displayName = $this->l('TSP Twitter');
		$this->description = $this->l('Displays a block for subscribing to your Twitter page');

		$this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
	}

	public function install() {
		if (!parent::install()) return false;

		// Activate every option by default
		Configuration::updateValue('TSPTW_TITLE', 'TSP Twitter');
		Configuration::updateValue('TSPTW_WIDGETSID', '668150811113844737');
		Configuration::updateValue('TSPTW_TWEETSCOUNT', '3');

		// The module will add a meta in the product page header and add a javascript file
		$this->registerHook('header');
		
		$this->registerHook('displayTwitter');
		

		// This hook could have been called only from the product page, but it's better to add the JS in all the pages with CCC
		/*
			$id_hook_header = Hook::getIdByName('header');
			$pages = array();
			foreach (Meta::getPages() as $page)
				if ($page != 'product')
					$pages[] = $page;
			$this->registerExceptions($id_hook_header, $pages);
		*/
		$this->_createTab();

		return true;
	}
	public function uninstall() {
		Configuration::deleteByName('TSPTW_TITLE');
		Configuration::deleteByName('TSPTW_WIDGETSID');
		Configuration::deleteByName('TSPTW_TWEETSCOUNT');
		
		$this->_deleteTab();
		return parent::uninstall();
	}
	public function getConfigFieldsValues() {
		$values = array();
		$values['TSPTW_TITLE'] = Tools::getValue('TSPTW_TITLE', Configuration::get('TSPTW_TITLE'));
		$values['TSPTW_WIDGETSID'] = Tools::getValue('TSPTW_WIDGETSID', Configuration::get('TSPTW_WIDGETSID'));
		$values['TSPTW_TWEETSCOUNT'] = Tools::getValue('TSPTW_TWEETSCOUNT', Configuration::get('TSPTW_TWEETSCOUNT'));
		return $values;
	}

	public function getContent() {
		if (Tools::isSubmit('submitTSPTwitter')) {
			
			Configuration::updateValue('TSPTW_TITLE', Tools::getValue('TSPTW_TITLE'));
			Configuration::updateValue('TSPTW_WIDGETSID', Tools::getValue('TSPTW_WIDGETSID'));
			Configuration::updateValue('TSPTW_TWEETSCOUNT', Tools::getValue('TSPTW_TWEETSCOUNT'));
			
			$this->html .= $this->displayConfirmation($this->l('Settings updated'));
			Tools::clearCache(Context::getContext()->smarty, $this->getTemplatePath('tsptwitter.tpl'));
			Tools::redirectAdmin($this->context->link->getAdminLink('AdminModules', true).'&conf=6&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name);
		}

		$helper = new HelperForm();
		$helper->submit_action = 'submitTSPTwitter';
		$helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->tpl_vars = array('fields_value' => $this->getConfigFieldsValues());


		$fields_form = array();
        $fields_form[0] = array(
            array(
                'type' => 'text',
                'label' => $this->l('Title'),
                'name' => 'TSPTW_TITLE',
                'class' => 'fixed-width-xl'
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Widgets Id'),
                'name' => 'TSPTW_WIDGETSID',
                'class' => 'fixed-width-xl'
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Tweets Count'),
                'name' => 'TSPTW_TWEETSCOUNT',
                'class' => 'fixed-width-xl'
            )
        );

		return $this->html.$helper->generateForm(array(
			array(
				'form' => array(
					'legend' => array(
						'title' => $this->l('General Options'),
						'icon' => 'icon-cogs'
					),
					'input' => $fields_form[0],
					'submit' => array(
						'title' => $this->l('Save')
					)
				)
			)
		));
	}

	public function hookDisplayHeader($params) {
       $this->context->smarty->assign(array(
        	'HOOK_FOOTER_TOP' => Hook::exec('displayFooterTop')
		));
		$this->context->controller->addJS($this->_path.'js/twitterfetcher-min.js');
		
	}

	protected function displayTSPTwitter() {
		if (!$this->isCached('tsptwitter.tpl', $this->getCacheId('tsptwitter'))) {
			$this->context->smarty->assign(array(
				'TSPTW_TITLE' => Configuration::get('TSPTW_TITLE'),
				'TSPTW_WIDGETSID' => Configuration::get('TSPTW_WIDGETSID'),
				'TSPTW_TWEETSCOUNT' => Configuration::get('TSPTW_TWEETSCOUNT'),
			));
		}
		
		return $this->display(__FILE__, 'tsptwitter.tpl', $this->getCacheId('tsptwitter'));
	}
	public function hookDisplayTwitter($params) {
		return $this->displayTSPTwitter();
	}
    //  CREATE THE TAB MENU
    private function _createTab() {
        $response = true;

        // First check for parent tab
        $parentTabID = Tab::getIdFromClassName('AdminTSP');

        if ($parentTabID) {
            $parentTab = new Tab($parentTabID);
        } else {
            $parentTab = new Tab();
            $parentTab->active = 1;
            $parentTab->name = array();
            $parentTab->class_name = "AdminTSP";
            foreach (Language::getLanguages() as $lang){
                $parentTab->name[$lang['id_lang']] = "TPL Solution";
            }
            $parentTab->id_parent = 0;
            $parentTab->module = $this->name;
            $response &= $parentTab->add();
        }

        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = "AdminTSPTwitter";
        $tab->name = array();
        foreach (Language::getLanguages() as $lang){
            $tab->name[$lang['id_lang']] = "TSP Twitter";
        }
        $tab->id_parent = $parentTab->id;
        $tab->module = $this->name;
        $response &= $tab->add();

        return $response;
    }
    private function _deleteTab() {
        $id_tab = Tab::getIdFromClassName('AdminTSPTwitter');
        $parentTabID = Tab::getIdFromClassName('AdminTSP');

        $tab = new Tab($id_tab);
        $tab->delete();

        $tabCount = Tab::getNbTabs($parentTabID);
        if ($tabCount == 0) {
            $parentTab = new Tab($parentTabID);
            $parentTab->delete();
        }
        return true;
    }
}
