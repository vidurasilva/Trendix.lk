<?php
/**
* 2015 Tpl Solution
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
*  @author    Tpl Solution <contact@tplsolution.com>
*  @copyright 2015 Tpl Solution
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of Tpl Solution
*/

if (!defined('_PS_VERSION_')) exit;

class TSPSobieSmartCodes extends Module {
    public static $static_shortcode_tags = array();
    public static $tsp_current_hook = '';
    public function parse ($str,$hook_name = '') {                   
        return self::do_shortcode($str,$hook_name);
    }
    public static function  add_shortcode($tag,$func) {
		self::$static_shortcode_tags[$tag] = $func;
    }
    public static function do_shortcode($content,$hook_name='') {
        $shortcode_tags = self::$static_shortcode_tags;
        if (empty($shortcode_tags) || !is_array($shortcode_tags))
                return $content;
        $pattern = self::get_shortcode_regex();
        self::$tsp_current_hook = $hook_name;
        return preg_replace_callback( "/$pattern/s", array(new TSPSobieSmartCodes,'do_shortcode_tag'), $content );
    }
    public static function do_shortcode_tag( $m ) {
        $shortcode_tags = self::$static_shortcode_tags;
        if ( $m[1] == '[' && $m[6] == ']' ) return substr($m[0], 1, -1);
        $tag = $m[2];
        $attr = self::shortcode_parse_atts( $m[3] );
		if ( isset( $m[5] ) ) 
			return $m[1] . call_user_func( $shortcode_tags[$tag], $attr, $m[5], $tag, self::$tsp_current_hook ) . $m[6];
		else 
			return $m[1] . call_user_func( $shortcode_tags[$tag], $attr, null,  $tag, self::$tsp_current_hook ) . $m[6];
    }
    public static function shortcode_parse_atts($text) {
        $atts = array();
        $pattern = '/(\w+)\s*=\s*"([^"]*)"(?:\s|$)|(\w+)\s*=\s*\'([^\']*)\'(?:\s|$)|(\w+)\s*=\s*([^\s\'"]+)(?:\s|$)|"([^"]*)"(?:\s|$)|(\S+)(?:\s|$)/';
        $text = preg_replace("/[\x{00a0}\x{200b}]+/u", " ", $text);
        if ( preg_match_all($pattern, $text, $match, PREG_SET_ORDER) ) {
            foreach ($match as $m) {
				if (!empty($m[1]))
					$atts[strtolower($m[1])] = stripcslashes($m[2]);
				elseif (!empty($m[3]))
					$atts[strtolower($m[3])] = stripcslashes($m[4]);
				elseif (!empty($m[5]))
					$atts[strtolower($m[5])] = stripcslashes($m[6]);
				elseif (isset($m[7]) and strlen($m[7]))
					$atts[] = stripcslashes($m[7]);
				elseif (isset($m[8]))
					$atts[] = stripcslashes($m[8]);
            }
        } else {
			$atts = ltrim($text);
        }
        return $atts;
    }
    public static function get_shortcode_regex() {
        $tagnames = array_keys(self::$static_shortcode_tags);
        $tagregexp = join( '|', array_map('preg_quote', $tagnames) );
        return
                  '\\['                              // Opening bracket
                . '(\\[?)'                           // 1: Optional second opening bracket for escaping shortcodes: [[tag]]
                . "($tagregexp)"                     // 2: Shortcode name
                . '(?![\\w-])'                       // Not followed by word character or hyphen
                . '('                                // 3: Unroll the loop: Inside the opening shortcode tag
                .     '[^\\]\\/]*'                   // Not a closing bracket or forward slash
                .     '(?:'
                .         '\\/(?!\\])'               // A forward slash not followed by a closing bracket
                .         '[^\\]\\/]*'               // Not a closing bracket or forward slash
                .     ')*?'
                . ')'
                . '(?:'
                .     '(\\/)'                        // 4: Self closing tag ...
                .     '\\]'                          // ... and closing bracket
                . '|'
                .     '\\]'                          // Closing bracket
                .     '(?:'
                .         '('                        // 5: Unroll the loop: Optionally, anything between the opening and closing shortcode tags
                .             '[^\\[]*+'             // Not an opening bracket
                .             '(?:'
                .                 '\\[(?!\\/\\2\\])' // An opening bracket not followed by the closing shortcode tag
                .                 '[^\\[]*+'         // Not an opening bracket
                .             ')*+'
                .         ')'
                .         '\\[\\/\\2\\]'             // Closing shortcode tag
                .     ')?'
                . ')'
                . '(\\]?)';                          // 6: Optional second closing brocket for escaping shortcodes: [[tag]]
    }
    public static function shortcode_atts( $pairs, $atts, $shortcode = '' ) {
        $atts = (array)$atts;
        $out = array();
        foreach($pairs as $name => $default) {
			if ( array_key_exists($name, $atts) ) {
				$out[$name] = $atts[$name];
				unset($atts[$name]);
			} else {
				$out[$name] = $default;
			}
        }
        $out = array_merge($out, $atts);
		if ( $shortcode )
			$out = apply_filters( "shortcode_atts_{$shortcode}", $out, $pairs, $atts );
        return $out;
    }
}

function tsp_tspb_section($atts, $content = null, $tag, $hook_name) {
    extract(TSPSobieSmartCodes::shortcode_atts(array(
		"bg_color" => "",
		"bg_image" => "",
		"class" => "",
		"bg_type" => "",
		"container" => "1",
		"bg_repeat" => "",
		"bg_attachment" => "",
		"bg_position" => "",
		"bg_size" => "",
		"pt" => "",
		"pr" => "",
		"pb" => "",
		"pl" => "",
		"mt" => "",
		"mr" => "",
		"mb" => "",
		"ml" => "",
    ), $atts));
    
	$style = '';
	if($bg_color) $style .= 'background-color: ' . $bg_color . ';';
	if($bg_image) $style .= 'background-image: url(' . $bg_image . ');';
	if($bg_repeat) $style .= 'background-repeat: ' . $bg_repeat . ';';
	if($bg_attachment) $style .= 'background-attachment: ' . $bg_attachment . ';';
	if($bg_position) $style .= 'background-position: ' . $bg_position . ';';
	if($bg_size) $style .= 'background-size: ' . $bg_size . ';';
	if((int)$pt) $style .= 'padding-top: ' . $pt . 'px;';
	if((int)$pr) $style .= 'padding-right: ' . $pr . 'px;';
	if((int)$pb) $style .= 'padding-bottom: ' . $pb . 'px;';
	if((int)$pl) $style .= 'padding-left: ' . $pl . 'px;';
	if((int)$mt) $style .= 'margin-top: ' . $mt . 'px;';
	if((int)$mr) $style .= 'margin-right: ' . $mr . 'px;';
	if((int)$mb) $style .= 'margin-bottom: ' . $mb . 'px;';
	if((int)$ml) $style .= 'margin-left: ' . $ml . 'px;';
    
    $html = '';
    $html .= '<div class="tsp-section '.$class.'"';
    $html .= ($bg_type == 'fullwidth') ? ' style="'.$style.'">' : '>';
    $html .= '<div class="tsp-section-in';
    $html .= ($container) ? ' container"' : '"';
    $html .= ($bg_type == 'boxed') ? ' style="'.$style.'">' : '>';
    
    $html .= '<div class="row">';
    $html .= '<div>';
    return $html;
}
TSPSobieSmartCodes::add_shortcode('tspb_section', 'tsp_tspb_section');

function tsp_tspb_column($atts, $content = null, $tag, $hook_name) {
    extract(TSPSobieSmartCodes::shortcode_atts(array(
		"class" => "",
		"xs" => "",
		"xs_hide" => "",
		"sm" => "12",
		"sm_hide" => "",
		"md" => "",
		"md_hide" => "",
		"lg" => "",
		"lg_hide" => "",
    ), $atts));
	if($xs) $class .= ' col-xs-'.$xs;
	if($sm) $class .= ' col-sm-'.$sm;
	if($md) $class .= ' col-md-'.$md;
	if($lg) $class .= ' col-lg-'.$lg;

	if($xs_hide) $class .= ' hidden-xs';
	if($sm_hide) $class .= ' hidden-sm';
	if($md_hide) $class .= ' hidden-md';
	if($lg_hide) $class .= ' hidden-lg';

    $html = '';
    $html .= '<div class="tsp-column '.$class.'">';
    $html .= '<div>';
    return $html;
}
TSPSobieSmartCodes::add_shortcode('tspb_column', 'tsp_tspb_column');

function tspb_hook($atts, $content = null, $tag, $hook_name) {
    $params = TSPSobieSmartCodes::shortcode_atts(array(
        'h' => '',
        'custom_h' => '',
	), $atts);
	$tsptheme = Module::getInstanceByName('tspsobietheme');
    return $tsptheme->getBlockHook($params);
}
TSPSobieSmartCodes::add_shortcode('tspb_hook', 'tspb_hook');

function tspb_banner($atts, $content = null, $tag, $banner_name) {
    extract(TSPSobieSmartCodes::shortcode_atts(array(
        'title' => ' ',
        'class' => '',
        'style' => '',
        'src' => '',
        'link' => '#',
    ), $atts));
    $html = '';
    if($src) {
    	$html .= '<a href="'.$link.'" title="'.$title.'" class="'.$style.' '.$class.'">';
    	$html .= '<img alt="'.$title.'" src="'.$src.'">';
    	$html .= '</a>';
    }
    return $html;
}
TSPSobieSmartCodes::add_shortcode('tspb_banner', 'tspb_banner');

function tspb_emptyspace($atts, $content = null, $tag, $hook_name) {
    extract(TSPSobieSmartCodes::shortcode_atts(array(
        'height' => '',
        'class' => '',
    ), $atts));
    return '<div style="height: '.(int)$height.'px;" class="clearfix '.$class.'">'.TSPSobieSmartCodes::do_shortcode($content,$hook_name).'</div>';
}
TSPSobieSmartCodes::add_shortcode('tspb_emptyspace', 'tspb_emptyspace');

function tspb_prdslider($atts = array(),$content = null, $tag, $hook_name){
    $params = TSPSobieSmartCodes::shortcode_atts(array(
					"title" 	=> "Product slider",
					"source" 	=> "new",
					"limit" 	=> "6",
					"orderby" 	=> "name",
					"orderway" 	=> "ASC",
					"xs" 		=> "2",
					"sm" 		=> "3",
					"md" 		=> "4",
					"lg" 		=> "5"
			    ), $atts);
	$tsptheme = Module::getInstanceByName('tspsobietheme');
    return $tsptheme->getBlockPrdSlider($params);
}
TSPSobieSmartCodes::add_shortcode('tspb_prdslider', 'tspb_prdslider');

function tspb_prdblock($atts = array(),$content = null, $tag, $hook_name){
    $params = TSPSobieSmartCodes::shortcode_atts(array(
					"title" 	=> "Product slider",
					"source" 	=> "new",
					"limit" 	=> "6",
					"orderby" 	=> "name",
					"orderway" 	=> "ASC",
					"lg" 		=> "",
					"md" 		=> "",
					"sm" 		=> "",
					"xs" 		=> "",
			    ), $atts);
	$tsptheme = Module::getInstanceByName('tspsobietheme');
    return $tsptheme->getBlockPrdBlock($params);
}
TSPSobieSmartCodes::add_shortcode('tspb_prdblock', 'tspb_prdblock');

function tspb_textblock($atts = array(),$content = null, $tag, $hook_name){
    extract(TSPSobieSmartCodes::shortcode_atts(array(
					"class" 	=> "",
			    ), $atts));
    return '<div class="'.$class.'">'.html_entity_decode(TSPSobieSmartCodes::do_shortcode($content,$hook_name)).'</div>';
}
TSPSobieSmartCodes::add_shortcode('tspb_textblock', 'tspb_textblock');



?>