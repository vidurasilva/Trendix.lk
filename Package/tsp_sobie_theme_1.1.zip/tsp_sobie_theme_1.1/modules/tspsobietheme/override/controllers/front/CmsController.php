<?php
/**
* 2015 TSPTheme
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
*  @author    TSPTheme <contact@tplsolution.com>
*  @copyright 2015 TSPTheme
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of TSPTheme
*/
class CmsController extends CmsControllerCore {
	/*
    * module: tspsobietheme
    * date: 2015-09-01 13:07:09
    * version: 1.0
    */
    public function initContent() {
		parent::initContent();
		if((bool)Module::isEnabled('tspsobietheme')) {
			if(context::getcontext()->controller->controller_type == 'front') {
				$tspsobietheme = Module::getInstanceByName('tspsobietheme');
				$this->cms->content = $tspsobietheme->parse($this->cms->content );
			}
		}
	}
}
