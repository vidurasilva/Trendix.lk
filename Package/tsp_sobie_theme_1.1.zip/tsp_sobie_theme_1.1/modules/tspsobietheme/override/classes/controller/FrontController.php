<?php
/**
* 2007-2015 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Open Software License (OSL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/osl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2015 PrestaShop SA
*  @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/
class FrontController extends FrontControllerCore
{
	/*
    * module: tspsobietheme
    * date: 2015-09-01 13:07:09
    * version: 1.0
    */
    public function displayHeader($display = true)
	{
		Tools::displayAsDeprecated();
		$this->initHeader();
		$hook_header = Hook::exec('displayHeader');
		if ((Configuration::get('PS_CSS_THEME_CACHE') || Configuration::get('PS_JS_THEME_CACHE')) && is_writable(_PS_THEME_DIR_.'cache'))
		{
			$ie_lt10 = false;
			if(isset($_SERVER['HTTP_USER_AGENT']) && $_SERVER['HTTP_USER_AGENT'])
				if(preg_match("/(?:msie )([0-9.]+)/i", $_SERVER['HTTP_USER_AGENT'], $ie))
					if($ie[1]<=9) $ie_lt10 = true;
			if (Configuration::get('PS_CSS_THEME_CACHE') && !$ie_lt10)
				$this->css_files = Media::cccCss($this->css_files);
			if (Configuration::get('PS_JS_THEME_CACHE'))
				$this->js_files = Media::cccJs($this->js_files);
		}
		$this->context->smarty->assign(array(
			'HOOK_HEADER'       => $hook_header,
			'HOOK_TOP'          => Hook::exec('displayTop'),
			'HOOK_LEFT_COLUMN'  => ($this->display_column_left  ? Hook::exec('displayLeftColumn') : ''),
			'HOOK_RIGHT_COLUMN' => ($this->display_column_right ? Hook::exec('displayRightColumn', array('cart' => $this->context->cart)) : ''),
			'HOOK_FOOTER'       => Hook::exec('displayFooter')
		));
		$this->context->smarty->assign(array(
			'css_files' => $this->css_files,
			'js_files'  => ($this->getLayout() && (bool)Configuration::get('PS_JS_DEFER')) ? array() : $this->js_files
		));
		$this->display_header = $display;
		$this->smartyOutputContent(_PS_THEME_DIR_.'header.tpl');
	}
	/*
    * module: tspsobietheme
    * date: 2015-09-01 13:07:09
    * version: 1.0
    */
    public function display()
	{
		Tools::safePostVars();
		if ((Configuration::get('PS_CSS_THEME_CACHE') || Configuration::get('PS_JS_THEME_CACHE')) && is_writable(_PS_THEME_DIR_.'cache'))
		{
			$ie_lt10 = false;
			if(isset($_SERVER['HTTP_USER_AGENT']) && $_SERVER['HTTP_USER_AGENT'])
				if(preg_match("/(?:msie )([0-9.]+)/i", $_SERVER['HTTP_USER_AGENT'], $ie))
					if($ie[1]<=9) $ie_lt10 = true;
			
			if (Configuration::get('PS_CSS_THEME_CACHE') && !$ie_lt10)
				$this->css_files = Media::cccCss($this->css_files);
			if (Configuration::get('PS_JS_THEME_CACHE') && !$this->useMobileTheme())
				$this->js_files = Media::cccJs($this->js_files);
		}
		$this->context->smarty->assign(array(
			'css_files'      => $this->css_files,
			'js_files'       => ($this->getLayout() && (bool)Configuration::get('PS_JS_DEFER')) ? array() : $this->js_files,
			'js_defer'       => (bool)Configuration::get('PS_JS_DEFER'),
			'errors'         => $this->errors,
			'display_header' => $this->display_header,
			'display_footer' => $this->display_footer,
		));
		$layout = $this->getLayout();
		if ($layout)
		{
			if ($this->template)
				$template = $this->context->smarty->fetch($this->template);
			else // For retrocompatibility with 1.4 controller
			{
				ob_start();
				$this->displayContent();
				$template = ob_get_contents();
				ob_clean();
			}
			$this->context->smarty->assign('template', $template);
			$this->smartyOutputContent($layout);
		}
		else
		{
			Tools::displayAsDeprecated('layout.tpl is missing in your theme directory');
			if ($this->display_header)
				$this->smartyOutputContent(_PS_THEME_DIR_.'header.tpl');
			if ($this->template)
				$this->smartyOutputContent($this->template);
			else // For retrocompatibility with 1.4 controller
				$this->displayContent();
			if ($this->display_footer)
				$this->smartyOutputContent(_PS_THEME_DIR_.'footer.tpl');
		}
		return true;
	}
}
