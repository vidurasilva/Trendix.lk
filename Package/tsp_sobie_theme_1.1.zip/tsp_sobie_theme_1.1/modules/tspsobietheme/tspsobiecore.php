<?php
/**
* 2015 Tpl Solution
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
*  @author    Tpl Solution <contact@tplsolution.com>
*  @copyright 2015 Tpl Solution
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of Tpl Solution
*/

if (!defined('_PS_VERSION_')) exit;

include_once(dirname(__FILE__) . '/tspsobieclass.php');
include_once(dirname(__FILE__) . '/tspsobieproduct.php');

class TSPSobieCore extends Module {
	var $urlConfig = '';
	
	public $dev_mode = false;
    public $themeFields;
    public $TSPClass;

	public function __construct() {
		parent::__construct();
		$this->TSPClass = new TSPSobieClass;
		$this->themeFields = $this->TSPClass->getThemeFields();
		$this->TSPClass->delField();
		
		global $currentIndex;
		$this->secure_key = Tools::encrypt($this->name);
		$this->urlConfig = $currentIndex . '&configure=' . $this->name . '&token=' . Tools::getValue('token');
	}
	protected function installFixtures() {
		$languages = Language::getLanguages(false);
  		foreach($this->themeFields as $key => $value) {
  			if(!$value['lang']) $this->updateValue($key, $value['default'], true);
		}
		foreach ($languages as $lang) $this->installFixture((int)$lang['id_lang']);
		return true;
	}
	
	protected function installFixture($id_lang) {
		foreach($this->themeFields as $key => $value) {
			if(is_array($value) && $value['lang']) {
				$values[$key][(int)$id_lang] = $value['default'];
				$this->updateValue($key, $values[$key], true);
			}
		}
	}
	public function callFontIcons() {
		$this->context->controller->addCSS(__PS_BASE_URI__ . 'modules/'.$this->name.'/assets/fonts/fontawesome/css/font-awesome.min.css', 'all');
		$this->context->controller->addCSS(__PS_BASE_URI__ . 'modules/'.$this->name.'/assets/fonts/tplicons/styles.css', 'all');
	}
	protected function addModMedia() {
		$this->context->controller->addJquery();
		$this->context->controller->addJqueryUI('ui.sortable');
		$this->context->controller->addjQueryPlugin(array('tagify'));
		$this->context->controller->addJS(__PS_BASE_URI__ . 'modules/'.$this->name.'/assets/admin/js/jquery.cookie.js');
		$this->context->controller->addJS(__PS_BASE_URI__ . 'modules/'.$this->name.'/assets/admin/js/editarea/edit_area_full.js');
		$this->context->controller->addJS(__PS_BASE_URI__ . 'modules/'.$this->name.'/assets/admin/iconpicker/js/iconset-fontawesome.min.js');
		$this->context->controller->addJS(__PS_BASE_URI__ . 'modules/'.$this->name.'/assets/admin/iconpicker/js/bootstrap-iconpicker.min.js');
		$this->context->controller->addCSS(__PS_BASE_URI__ . 'modules/'.$this->name.'/assets/admin/iconpicker/css/bootstrap-iconpicker.min.css', 'all');
		
		$this->context->controller->addCSS(__PS_BASE_URI__ . 'modules/'.$this->name.'/assets/fonts/fontawesome/css/font-awesome.min.css', 'all');
		
		$this->context->controller->addJS(__PS_BASE_URI__ . 'modules/'.$this->name.'/assets/admin/js/tsp-scripts.js');
	}

	public function getPatterns( $field = 'TSP_SBE_BODYIMG', $valcpl = '' ){
		$patterns = array();
		$path = _PS_ALL_THEMES_DIR_. _THEME_NAME_."/img/patterns";
		$regex = '/(\.gif)|(.jpg)|(.png)|(.bmp)$/i';
		if( !is_dir($path) ) return;
		
		$dk =  opendir ( $path );
		$files = array();
		while ( false !== ($filename = readdir ( $dk )) ) {
			if (preg_match ( $regex, $filename )) {
				$files[] = $filename;
			}
		}
		foreach( $files as $p ) $patterns[] = $p;
		
		return $patterns;
	}
	public function getBaseUrl(){
		if (!empty($_SERVER['HTTPS']) && ('on' == $_SERVER['HTTPS']))
			return 'https://'.Tools::getShopDomain();
		else
			return 'http://'.Tools::getShopDomain();
	}
	protected function getPatternsHTML($front=false, $curr=false) {
		$html = '<div class="radio_img_group">';
		$patternsURL = $this->getBaseUrl().__PS_BASE_URI__."themes/"._THEME_NAME_."/img/patterns/";
		
		if($front) $inputName = 'TSP_SBECP_BODYIMG';
		else $inputName = 'TSP_SBE_BODYIMG';
		
		if(is_array($this->getPatterns())) {
			if($front && $curr) 
				$curent = $curr;
			else
				$curent = Tools::getValue('TSP_SBE_BODYIMG', Configuration::get('TSP_SBE_BODYIMG'));
			
			foreach ($this->getPatterns() as $val) {
				$checked = '';
				if($curent == $val) $checked = ' checked="checked"';
				$html .= '<label title="'.$val.'" style="display: inline-block;">';
				$html .= '<input'.$checked.' type="radio" class="skip_uniform" value="'.$val.'" name="'.$inputName.'">';
				$html .= '<span style="background-image: url('.$patternsURL.$val.')"></span>';
				$html .= '</label>';
			}
		}
		$html .= '</div>';
		
		return $html;
	}
	public function tspSerialize ($serializ) {
		if(!is_array($serializ)) return;
		foreach($serializ as $key => $row) {
			if(count($row)) {
				$remove = true;
				foreach($row as $fieldk => $field) {
					$remove &= ((bool)$field) ? false : true;
					if($field) {
						$serializ[$key][$fieldk] = $this->TSPClass->replaceLinkContent($field);
					}
				}
				if($remove) unset($serializ[$key]);
			} else {
				unset($serializ[$key]);
			}
		}
		return serialize($serializ);
	}
	public function tspUnSerialize ($serialized) {
		$fields = Tools::unSerialize($serialized);
		
		if($fields) {
			foreach($fields as $id => $field) {
				foreach($field as $name => $v) {
					$fields[$id][$name] = $this->TSPClass->replaceLinkContent($v, true);
				}
			}
			return $fields;
		}
		return false;
	}
	public function updateFields($section = false) {
		$fields = $this->TSPClass->getThemeFields($section);
		
		$languages = Language::getLanguages(false);
    	$submitValues = array();
    	$additem_val = array();
    	
		foreach ($languages as $lang) {
	  		foreach($fields as $key => $value) {
	  			if($value['lang'] && $value['type'] == false) {
					$tspb_data = $this->TSPClass->replaceLinkContent(Tools::getValue($key.'_'.$lang['id_lang']));
	  				if($key == 'TSP_SBE_HOMEPAGE_TSPB') {
						$tspb_data = preg_replace('/<!-- backend -->(.*?)<!-- \/backend -->/s', '', $tspb_data);
						$tspb_data = preg_replace('/(\t|\n|\r)/s', '', $tspb_data);
					}
					$submitValues[$key][$lang['id_lang']] = $tspb_data;
	  			}
	  			if($value['type'] == 'additem'){
					$additem_val[$key][$lang['id_lang']] = $this->tspSerialize(Tools::getValue($key.'_'.$lang['id_lang']));
	  			}
			}
		}
  		foreach($fields as $key => $value) {
  			if($value['lang'] && $value['type'] == false) {
				$this->updateValue($key, $submitValues[$key], true);
  			} elseif($value['type'] == 'additem'){
				$this->updateValue($key, $additem_val[$key], true);
  			} elseif($value['type'] == 'multiple_select'){
				$multiple = Tools::getValue ($key);
				$field_select = ( is_array($multiple) && !empty( $multiple ) ) ? implode (',', $multiple) : '';
				$this->updateValue($key, $field_select, true);
  			} else {
				$this->updateValue($key, $this->TSPClass->replaceLinkContent(Tools::getValue($key)), true);
  			}
		}
	    $this->clearCacheTPL();
		if($section = false || $section = 'tspp_general')
			$this->updateValue('PS_QUICK_VIEW', Tools::getValue('PS_QUICK_VIEW'), true);
		
		return true;
	}
	public function exportFields() {
		$sections = $this->getTabs();
		$html = '';
		foreach($sections as $section) {
			$section = str_replace('fieldset_', '', $section);
			$fields = $this->TSPClass->getThemeFields($section);
			$html .= "$" . $section . " = array(\n";
	  		foreach($fields as $key => $value) {
	  			if(!$value['type'] && !$value['lang']) {
					$html .= "\t'" . $key . "' => '" . preg_replace("/\r|\n/", "", Configuration::get($key)) . "',\n";
	  			} else {
					$html .= "\t'" . $key . "' => array(\n";
					if($value['lang']){
						$html .= "\t\t" . "'default' => '" . preg_replace("/\r|\n|\t/", "", Configuration::get($key, Configuration::get('PS_LANG_DEFAULT'))) . "',\n";
						$html .= "\t\t" . "'lang' => 'true',\n";
					} else {
						$html .= "\t\t" . "'default' => '" . preg_replace("/\r|\n|\t/", "", Configuration::get($key)) . "',\n";
					}
					if($value['type']) $html .= "\t\t" . "'type' => '" . $value['type'] . "',\n";
					$html .= "\t),\n";
	  			}
			}
			$html .= ");\n";
			
		}
		$sampledata_dir = dirname(__FILE__) . DS . 'sampledata' . DS;
		file_put_contents($sampledata_dir .'themeconfig.php', $html);
	}
	public function actionImportExport($action, $folder, $params) {
		$sampledata_dir = dirname(__FILE__) . DS . $folder . DS;
		if($action == 'import'){
	    	$import_data = explode('|', $params);
	    	$field_name = $import_data[0];
	    	if(isset($import_data[1])) {
	    	    $lang_id = $import_data[1];
	    	    $filename = Tools::getValue($field_name.'_'.$lang_id.'_import_name');
				
				$data = Tools::file_get_contents($sampledata_dir . $filename);
				
				Configuration::updateValue($field_name, array($lang_id => $data), true);
	    	} else {
	    	    $filename = Tools::getValue($field_name.'_import_name');
				$data = Tools::file_get_contents($sampledata_dir . $filename);
				Configuration::updateValue($field_name, $data, true);
	    	}
	    	return $this->displayConfirmation('Import successful');
		} elseif($action == 'export'){
    	    $field_name = $params;
    	    $filename = Tools::getValue($field_name.'_export_name');
    	    
			$data = Tools::getValue($field_name);
			
			if($folder == 'tspbdata') {
				$data = preg_replace('/<!-- backend -->(.*?)<!-- \/backend -->/s', '', $data);
				$data = preg_replace('/(\t|\n|\r)/s', '', $data);
			}
			
			if(file_put_contents($sampledata_dir . $filename .'.html', $data)) 
	    	    return $this->displayConfirmation($this->l('Successful export to '.$filename.'.html'));
	    	else
	    	    return $this->displayError('Export error');
		}
	}
	public function actionExportCfg($lang_id) {
    	$filename = Tools::getValue('export_cfg_name_'.$lang_id);
		$data = array();
  		foreach($this->themeFields as $key => $value) {
  			if($value['lang']) {
  				$data[$key] = array(
  					'data' => Configuration::get($key, $lang_id),
  					'lang' => $lang_id
  				);
  			} else {
  				$data[$key] = array(
  					'data' => Configuration::get($key)
  				);
  			}
		}
		$data = serialize($data);
		$data_dir = dirname(__FILE__) . DS . 'data_config' . DS;
		if(file_put_contents($data_dir . $filename . '.txt', $data)) 
    	    return $this->displayConfirmation('Successful export to '.$filename.'.txt');
    	else
    	    return $this->displayError('Export error');
	}
	public function actionImportCfg($lang_id) {
    	$filename = Tools::getValue('import_cfg_name_'.$lang_id);
		$config = Tools::file_get_contents(dirname(__FILE__) . DS . 'data_config' . DS . $filename);
		$config = Tools::unSerialize($config);
		foreach($config as $field_name => $value) {
			if(isset($value['lang']) && $value['lang']) {
				Configuration::updateValue($field_name, array($lang_id => $value['data']), true);
			} else {
				Configuration::updateValue($field_name, $value['data'], true);
			}
		}
	    return $this->displayConfirmation('Import Successful');
	}
	public function getContent() {
		if($this->dev_mode) $this->exportFields();
	    $output = null;

	    if (Tools::isSubmit('import_data')) $output .= $this->actionImportExport('import', 'sampledata', $_POST['import_data']);
	    elseif (Tools::isSubmit('export_data')) $output .= $this->actionImportExport('export', 'sampledata', $_POST['export_data']);
	    elseif (Tools::isSubmit('import_tspb_data')) $output .= $this->actionImportExport('import', 'tspbdata', $_POST['import_tspb_data']);
	    elseif (Tools::isSubmit('export_tspb_data')) $output .= $this->actionImportExport('export', 'tspbdata', $_POST['export_tspb_data']);
	    elseif (Tools::isSubmit('export_cfg')) $output .= $this->actionExportCfg($_POST['export_cfg']);
	    elseif (Tools::isSubmit('import_cfg')) $output .= $this->actionImportCfg($_POST['import_cfg']);
	    elseif (Tools::isSubmit('submit'.$this->name)) {  
	    	$this->updateFields();
    	    $output .= $this->displayConfirmation('Settings updated');
	    }
	    $output .= $this->getFormHTML();
	    return $output;
	}
	public function getConfigFieldsValues() {
		
		$values = array();
		$languages = Language::getLanguages(false);
		
  		foreach($this->themeFields as $key => $value) {
  			if(!$value['lang']) {
  				if($value['type'] == 'multiple_select'){
					$kv = Configuration::get($key);
					$values[$key.'[]'] = ( isset($kv) && $kv !== false ) ? explode(',', $kv) : false;
  				} else {
					$values[$key] = $this->TSPClass->replaceLinkContent(Configuration::get($key), true);
  				}
  			}
		}
		foreach ($languages as $lang) {
	  		foreach($this->themeFields as $key => $value) {
	  			if($value['lang'] && $value['type'] == false) {
					$values[$key][$lang['id_lang']] = $this->TSPClass->replaceLinkContent(Configuration::get($key, $lang['id_lang']), true);
	  			}
			}
		}
		
		$values['PS_QUICK_VIEW'] = Configuration::get('PS_QUICK_VIEW');
		
		return $values;
	}

	protected function getAdditemData($field) {
		$values = array();
		$languages = Language::getLanguages(false);
		foreach ($languages as $lang) {
			$id_lang = $lang['id_lang'];
			$arrayValue = $this->tspUnSerialize(Configuration::get($field, $id_lang));
			if($arrayValue) {
				$values[$id_lang] = $arrayValue;
			}
		}
		return $values;
	}

	protected function getFormHTML() {
		$helper = new HelperForm();
		$helper->show_toolbar = false;
		$helper->table =  $this->table;
		$lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
		$helper->default_form_language = $lang->id;
		$helper->module = $this;
		$helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
		$helper->identifier = $this->identifier;
		$helper->submit_action = 'submit'.$this->name;
		$helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->tpl_vars = array(
			'uri' => $this->getPathUri(),
			'fields_value' => $this->getConfigFieldsValues(),
			'languages' => $this->context->controller->getLanguages(),
			'id_language' => $this->context->language->id,
			'tsptabs' => $this->getTabs(),
			'patterns_html' => $this->getPatternsHTML(),
			'controller_url' => $this->context->link->getAdminLink('AdminTSPSobieTheme'),
			'theme_info' => $this->displayName . ' v' . $this->version,
            'config_data' => $this->getConfigData(),
            'import_data' => $this->getSampleData('sampledata'),
            'import_tspb_data' => $this->getSampleData('tspbdata'),
		);

		return $helper->generateForm(array(
			'tspp_general' => $this->generalSettings('tspp_general'),
			'tspp_header' => $this->headerSettings('tspp_header'),
			'tspp_homepage' => $this->homepageSettings('tspp_homepage'),
			'tspp_slideshow' => $this->slideshowSettings('tspp_slideshow'),
			'tspp_testimonial' => $this->testimonialSettings('tspp_testimonial'),
			'tspp_social' => $this->socialSettings('tspp_social'),
			'tspp_ourbrand' => $this->ourbrandSettings('tspp_ourbrand'),
			'tspp_events' => $this->eventsSettings('tspp_events'),
			'tspp_advance' => $this->advanceSettings('tspp_advance'),
			'tspp_customcssjs' => $this->customCssJsSetting('tspp_customcssjs')
		));
	}
    protected function getTabs() {
        $tabArray = array(
            'General' => 'fieldset_tspp_general',
            'Header & Footer' => 'fieldset_tspp_header',
            'Homepage' => 'fieldset_tspp_homepage',
            'Slideshow' => 'fieldset_tspp_slideshow',
            'Testimonial' => 'fieldset_tspp_testimonial',
            'Social' => 'fieldset_tspp_social',
            'Our Brand' => 'fieldset_tspp_ourbrand',
            'Events' => 'fieldset_tspp_events',
            'Advance' => 'fieldset_tspp_advance',
            'Custom CSS, JS' => 'fieldset_tspp_customcssjs'
        );
        return $tabArray;
    }
	protected function getFontsList() {
		$basefonts = array(
			"Arial, Helvetica, sans-serif",
			"'Arial Black', Gadget, sans-serif",
			"'Bookman Old Style', serif",
			"'Comic Sans MS', cursive",
			"Courier, monospace",
			"Garamond, serif",
			"Georgia, serif",
			"Impact, Charcoal, sans-serif",
			"'Lucida Console', Monaco, monospace",
			"'Lucida Sans Unicode', 'Lucida Grande', sans-serif",
			"'MS Sans Serif', Geneva, sans-serif",
			"'MS Serif', 'New York', sans-serif",
			"'Palatino Linotype', 'Book Antiqua', Palatino, serif",
			"Tahoma,Geneva, sans-serif",
			"'Times New Roman', Times,serif",
			"'Trebuchet MS', Helvetica, sans-serif",
			"Verdana, Geneva, sans-serif"
		);
		$query_basefonts = array();
		foreach($basefonts as $font) {
			$query_basefonts[] = array('id' => $font, 'name' => $font);
		}
		
		$gfonts = Tools::file_get_contents(dirname(__FILE__) . DS . 'assets' . DS . 'webfonts.json');
		
		$gfonts = Tools::jsonDecode($gfonts);
		
		$gfont_cat = array();
		foreach($gfonts->items as $item) {
			$gfont_cat[$item->category][] = array(
				'id'	=> 'GF:' . $item->family . ':' . implode(',', $item->variants) . ':' . implode(',', $item->subsets),
				'name'	=> $item->family,
				'family'	=> $item->family,
				'variants'	=> $item->variants,
				'subsets'	=> $item->subsets,
			);
		}
		
		$query = array();
		$query[] = array(
						'name' => 'Base fonts',
						'query' => $query_basefonts
						);
		foreach($gfont_cat as $cat => $fonts) {
			$query[] = array(
					'name' => 'Google font - ' . $cat,
					'query' => $fonts
				);
		}
		
		$fonts = array(
					'default' => array('value' => 0, 'label' => 'None'),
					'optiongroup' => array(
						'label' => 'name',
						'query' => $query,
					),
					'options' => array(
						'id' => 'id',
						'name' => 'name',
						'query' => 'query',
					),
				);
		return $fonts;
	}
	protected function getTpl($pattern) {
		$return = array();
		$theme_dir = _PS_ALL_THEMES_DIR_._THEME_NAME_.DS;
		$tpls = glob($theme_dir.$pattern.'*.tpl');
		if(is_array($tpls) && count($tpls)) {
			foreach($tpls as $tpl) {
				preg_match('/'.$pattern.'(.*?)+.tpl$/i', $tpl, $matches);
				if(is_array($matches) && count($matches) && $matches[0])
					$return[] = array('id' => $matches[0], 'name' => str_replace('.tpl', '',$matches[0]));
			}
		}
		return $return;
	}
	protected function generalSettings($tab_name) {
		$fields_form = array(
			array(
                'type' => 'color',
                'label' => $this->l('Theme Color #1'),
                'name' => 'TSP_SBE_THEMECOLOR'
			),
//			array(
//                'type' => 'color',
//                'label' => $this->l('Theme Color #2'),
//                'name' => 'TSP_SBE_THEMECOLOR2'
//			),
			array(
				'type' => 'text',
				'label' => $this->l('Warpper max width'),
				'name' => 'TSP_SBE_WRAPPERWIDTH',
				'class' => 'fixed-width-md',
				'suffix' => 'px',
				'desc' => 'min: 1200',
			),
			array(
				'type' => 'select',
				'class' => 'chosen',
                'label' => $this->l('Primary Font'),
				'name' => 'TSP_SBE_FONT1',
				'options' => $this->getFontsList()
			),
			array(
				'type' => 'select',
                'label' => $this->l('Font size'),
				'name' => 'TSP_SBE_FONTSIZE',
				'options' => array(
					'query' => array(
									array('id' => '10px', 'name' => '10px'),
									array('id' => '11px', 'name' => '11px'),
									array('id' => '12px', 'name' => '12px'),
									array('id' => '13px', 'name' => '13px'),
									array('id' => '14px', 'name' => '14px'),
									array('id' => '15px', 'name' => '15px'),
									array('id' => '16px', 'name' => '16px'),
								),
					'id' => 'id',
					'name' => 'name'
				)
			),
			array(
                'type' => 'color',
                'label' => $this->l('Body bg color'),
                'name' => 'TSP_SBE_BODYCOLOR'
            ),
			array(
                'type' => 'pattern_choice',
                'label' => $this->l('Body bg img'),
                'name' => 'TSP_SBE_BODYIMG'
            ),
			array(
                'type' => 'select',
				'class' => 'chosen',
                'label' => $this->l('Secondary Font'),
                'name' => 'TSP_SBE_FONT2',
				'options' => $this->getFontsList()
            ),
			array(
				'type' => 'tagify',
				'label' => $this->l('Secondary Font Targets'),
				'name' => 'TSP_SBE_FONT2TARGETS',
				'hint' => $this->l('To add "Selector," click in the field, write selector, and then press "Enter."'),
				'desc' => '<a href="http://www.w3schools.com/cssref/css_selectors.asp" target="_blank">' . $this->l('CSS Selector') . '</a>',
				'placeholder' => $this->l('Add Target'),
			),
			array(
                'type' => 'select',
				'class' => 'chosen',
                'label' => $this->l('Tertiary Font'),
                'name' => 'TSP_SBE_FONT3',
				'options' => $this->getFontsList()
            ),
			array(
				'type' => 'tagify',
				'label' => $this->l('Tertiary Font Targets'),
				'name' => 'TSP_SBE_FONT3TARGETS',
				'hint' => $this->l('To add "Selector," click in the field, write selector, and then press "Enter."'),
				'desc' => '<a href="http://www.w3schools.com/cssref/css_selectors.asp" target="_blank">' . $this->l('CSS Selector') . '</a>',
				'placeholder' => $this->l('Add Target'),
			),
			$this->field_onOff('TSP_SBE_SECONDIMG', 'Display second image'),
			$this->field_onOff('PS_QUICK_VIEW', 'Quick View'),
			$this->field_onOff('TSP_SBE_ADDTHISBTN', 'Use sharing button of Addthis on product page'),
			array(
				'type' => 'iconpicker',
				'label' => $this->l('Cart icon'),
				'name' => 'TSP_SBE_ICOCART',
				'input_hidden' => true
			),
			array(
				'type' => 'iconpicker',
				'label' => $this->l('Quickview icon'),
				'name' => 'TSP_SBE_ICOQUICKVIEW',
				'input_hidden' => true
			),
			array(
				'type' => 'iconpicker',
				'label' => $this->l('Compare icon'),
				'name' => 'TSP_SBE_ICOCOMPARE',
				'input_hidden' => true
			),
			array(
				'type' => 'iconpicker',
				'label' => $this->l('Wishlist icon'),
				'name' => 'TSP_SBE_ICOWISHLIST',
				'input_hidden' => true
			),
			array(
				'type' => 'select',
                'label' => $this->l('Business Hour'),
				'name' => 'TSP_SBE_BUSINESSHOUR',
				'hint' => 'Choose store for hook displayBusinessHour',
				'options' => array(
					'query' => $this->getStoreNames(),
					'id' => 'id',
					'name' => 'name'
				)
			),
			array(
				'type' => 'select',
                'label' => $this->l('Contac Us'),
				'name' => 'TSP_SBE_CONTACTUS',
				'hint' => 'Choose store for hook displayContacUs',
				'options' => array(
					'query' => $this->getStoreNames(),
					'id' => 'id',
					'name' => 'name'
				)
			),
        );
		return $this->getFormSection($fields_form, 'General settings', $tab_name);
	}
    public function getStoreNames() {
        $stores = Db::getInstance()->executeS('
		SELECT s.*, cl.name country, st.iso_code state
		FROM '._DB_PREFIX_.'store s
		'.Shop::addSqlAssociation('store', 's').'
		LEFT JOIN '._DB_PREFIX_.'country_lang cl ON (cl.id_country = s.id_country)
		LEFT JOIN '._DB_PREFIX_.'state st ON (st.id_state = s.id_state)
		WHERE cl.id_lang = '.(int)$this->context->language->id);
		
		$return = array();
		foreach ($stores as $store) {
			$return[] = array('id' => $store['id_store'], 'name' => $store['name']);
		}
        return $return;
    }
	protected function headerSettings($tab_name) {
		$fields_form = array(
			array(
                'type' => 'heading',
            	'title' => 'Header',
            	'name' => 'header'
            ),
			$this->field_text ('TSP_SBE_WELCOMEMESS', 'Welcome mess', 'fixed-width-xl', true),
			$this->field_onOff('TSP_SBE_CUSTOMLOGO', 'Use custom logo'),
			array(
                'type' => 'tsp_image',
                'label' => $this->l('Custom logo'),
                'name' => 'TSP_SBE_CUSTOMLOGO_URL',
            	'lang' => true
            ),
			array(
				'type' => 'select',
                'label' => $this->l('Header style'),
				'name' => 'TSP_SBE_HEADER_STYLE',
				'options' => array(
					'query' => $this->getTpl('header-style'),
					'id' => 'id',
					'name' => 'name'
				)
			),
			$this->field_onOff('TSP_SBE_STICKYMENU', 'Use sticky menu'),
			array(
                'type' => 'heading',
            	'title' => 'Footer',
            	'name' => 'footer'
            ),
			array(
				'type' => 'select',
                'label' => $this->l('Footer style'),
				'name' => 'TSP_SBE_FOOTER_STYLE',
				'options' => array(
					'query' => $this->getTpl('footer-style'),
					'id' => 'id',
					'name' => 'name'
				)
			),
			array(
                'type' => 'tsp_image',
                'label' => $this->l('Footer logo'),
                'name' => 'TSP_SBE_FOOTER_LOGO',
            	'lang' => true
            ),
			array(
				'type' => 'select',
                'label' => $this->l('Footer links'),
				'name' => 'TSP_SBE_FOOTERLINKS[]',
				'multiple' => true,
				'options' => array(
					'query' => array(
						array('id' => 'our_stores', 'name' => 'Our stores'),
						array('id' => 'price_drop', 'name' => 'Price drop'),
						array('id' => 'new_products', 'name' => 'New products'),
						array('id' => 'best_sales', 'name' => 'Best sales'),
						array('id' => 'contact_us', 'name' => 'Contact us'),
						array('id' => 'sitemap', 'name' => 'Sitemap')
					),
					'id' => 'id',
					'name' => 'name'
				)
            ),
            
			$this->field_textarea ('TSP_SBE_FOOTER', 'Footer content', '', true, true),
			$this->field_text ('TSP_SBE_COPYRIGHT', 'Copyright', '', true),
            array(
                'type' => 'tsp_image',
                'label' => $this->l('Payment logo'),
                'name' => 'TSP_SBE_PAYMENTLOGO',
            	'lang' => true
            )
        );
		return $this->getFormSection($fields_form, 'Header Settings', $tab_name);
	}
	public function getAnimate(){
		$transitions = array(
			'Attention Seekers' => array( 'bounce', 'flash', 'pulse', 'rubberBand', 'shake', 'swing', 'tada', 'wobble' ),
			'Bouncing Entrances' => array( 'bounceIn', 'bounceInDown', 'bounceInLeft', 'bounceInRight', 'bounceInUp' ),
			'Bouncing Exits' => array( 'bounceOut', 'bounceOutDown', 'bounceOutLeft', 'bounceOutRight', 'bounceOutUp' ),
			'Fading Entrances' => array( 'fadeIn', 'fadeInDown', 'fadeInDownBig', 'fadeInLeft', 'fadeInLeftBig', 'fadeInRight', 'fadeInRightBig', 'fadeInUp', 'fadeInUpBig' ),
			'Fading Exits' => array( 'fadeOut', 'fadeOutDown', 'fadeOutDownBig', 'fadeOutLeft', 'fadeOutLeftBig', 'fadeOutRight', 'fadeOutRightBig', 'fadeOutUp', 'fadeOutUpBig' ),
			'Flippers' => array( 'flip', 'flipInX', 'flipInY', 'flipOutX', 'flipOutY' ),
			'Lightspeed' => array( 'lightSpeedIn', 'lightSpeedOut' ),
			'Rotating Entrances' => array( 'rotateIn', 'rotateInDownLeft', 'rotateInDownRight', 'rotateInUpLeft', 'rotateInUpRight' ),
			'Rotating Exits' => array( 'rotateOut', 'rotateOutDownLeft', 'rotateOutDownRight', 'rotateOutUpLeft', 'rotateOutUpRight' ),
			'Sliding Entrances' => array( 'slideInUp', 'slideInDown', 'slideInLeft', 'slideInRight' ),
			'Sliding Exits' => array( 'slideOutUp', 'slideOutDown', 'slideOutLeft', 'slideOutRight' ),
			'Zoom Entrances' => array( 'zoomIn', 'zoomInDown', 'zoomInLeft', 'zoomInRight', 'zoomInUp' ),
			'Zoom Exits' => array( 'zoomOut', 'zoomOutDown', 'zoomOutLeft', 'zoomOutRight', 'zoomOutUp' ),
			'Specials' => array( 'hinge', 'rollIn', 'rollOut' )
			);
		
		$query = array();
		foreach($transitions as $group => $animations) {
			$animates = array();
			foreach($animations as $animate)
				$animates[] = array('id' => $animate, 'name' => $animate);
			$query[] = array('name' => $group, 'query' => $animates);
		}
		return array(
					'optiongroup' => array(
						'label' => 'name',
						'query' => $query
					),
					'options' => array(
						'id' => 'id',
						'name' => 'name',
						'query' => 'query',
					),
				);
	}
	public function getSampleData($folder) {
		$sampledata_dir = dirname(__FILE__) . DS . $folder . DS;
		$sampledatas = glob($sampledata_dir.'*.html');
		foreach($sampledatas as $key => $sampledata) {
			$sampledatas[$key] = str_replace($sampledata_dir, '', $sampledata);
		}
		return $sampledatas;
	}
	public function getConfigData() {
		$configdata_dir = dirname(__FILE__) . DS . 'data_config' . DS;
		$configdatas = glob($configdata_dir.'*.txt');
		foreach($configdatas as $key => $configdata) {
			$configdatas[$key] = str_replace($configdata_dir, '', $configdata);
		}
		return $configdatas;
	}
	protected function slideshowSettings($tab_name) {
		$fields_form = array(
			$this->field_onOff('TSP_SBE_SLSTATUS', 'Enabled'),
			array(
				'type' => 'text',
				'label' => $this->l('Width'),
				'name' => 'TSP_SBE_SLWIDTH',
				'class' => 'fixed-width-xs',
				'suffix' => 'px'
			),
			array(
				'type' => 'text',
				'label' => $this->l('Height'),
				'name' => 'TSP_SBE_SLHEIGHT',
				'class' => 'fixed-width-xs',
				'suffix' => 'px'
			),
			array(
				'type' => 'text',
				'label' => $this->l('Auto Play'),
				'name' => 'TSP_SBE_SLAUTO',
				'class' => 'fixed-width-xs',
				'suffix' => 'ms'
			),
			array(
				'type' => 'select',
				'class' => 'chosen',
                'label' => $this->l('Animate In'),
				'name' => 'TSP_SBE_SLANIMATEIN',
				'options' => $this->getAnimate()
			),
			array(
				'type' => 'select',
				'class' => 'chosen',
                'label' => $this->l('Animate OUT'),
				'name' => 'TSP_SBE_ANIMATEOUT',
				'options' => $this->getAnimate()
			),
            array(
                'label' => $this->l('Images'),
                'name' => 'TSP_SBE_SLIMGS',
            	'lang' => true,
				'type' => 'additem',
				'btn' => $this->l('Add Image'),
				'data' => $this->getAdditemData('TSP_SBE_SLIMGS'),
				'fields' => array(
					array(
						'label' => $this->l('Title'),
						'name' => 'title',
						'type' => 'text',
						'width' => '2'
					),
					array(
						'label' => $this->l('Link'),
						'name' => 'link',
						'type' => 'text',
						'width' => '3'
					),
					array(
						'label' => $this->l('Image'),
						'name' => 'img',
						'type' => 'image',
						'width' => '4'
					),
				)
            )
        );
		return $this->getFormSection($fields_form, 'Slideshow Settings', $tab_name);
	}
	protected function homepageSettings($tab_name) {
		$fields_form = array(
			array(
				'type' => 'tspb',
				'name' => 'TSP_SBE_HOMEPAGE_TSPB',
				'label' => 'Home page content',
			)
        );
		return $this->getFormSection($fields_form, 'Homepage Settings', $tab_name);
	}
	protected function testimonialSettings($tab_name) {
		$fields_form = array(
			$this->field_onOff('TSP_SBE_TESTIMONIAL_STATUS', 'Enabled'),
			$this->field_text ('TSP_SBE_TESTIMONIAL_TITLE', 'Title', 'fixed-width-xl', true),
			$this->field_textarea ('TSP_SBE_TESTIMONIAL_DESC', 'Description', '', true),
            array(
                'label' => $this->l('Testimonials'),
                'name' => 'TSP_SBE_TESTIMONIALS',
            	'lang' => true,
				'type' => 'additem',
				'btn' => $this->l('Add Brand'),
				'data' => $this->getAdditemData('TSP_SBE_TESTIMONIALS'),
				'fields' => array(
					array(
						'label' => $this->l('Title'),
						'name' => 'title',
						'type' => 'text',
						'width' => '2'
					),
					array(
						'label' => $this->l('Name'),
						'name' => 'name',
						'type' => 'text',
						'width' => '2'
					),
					array(
						'label' => $this->l('Avatar'),
						'name' => 'avatar',
						'type' => 'image',
						'width' => '3'
					),
					array(
						'label' => $this->l('Desc'),
						'name' => 'desc',
						'type' => 'textarea',
						'width' => '3',

					),
				)
            )
        );
		return $this->getFormSection($fields_form, 'Testimonials Settings', $tab_name);
	}
	protected function socialSettings($tab_name) {
		$fields_form = array(
			$this->field_onOff('TSP_SBE_SOCIAL_STATUS', 'Enabled'),
			$this->field_text ('TSP_SBE_SOCIAL_TITLE', 'Title', 'fixed-width-xl', true),
            array(
                'label' => $this->l('Social link'),
                'name' => 'TSP_SBE_SOCIAL',
            	'lang' => true,
				'type' => 'additem',
				'btn' => $this->l('Add item'),
				'data' => $this->getAdditemData('TSP_SBE_SOCIAL'),
				'iconpicker' => true,
				'fields' => array(
					array(
						'label' => $this->l('Title'),
						'name' => 'title',
						'type' => 'text',
						'width' => '2'
					),
					array(
						'label' => $this->l('Link'),
						'name' => 'link',
						'type' => 'text',
						'width' => '3'
					),
					array(
						'label' => $this->l('Icon class'),
						'name' => 'icon',
						'type' => 'text',
						'width' => '2'
					),
					array(
						'label' => $this->l('Target'),
						'name' => 'target',
						'type' => 'select',
						'width' => '1',
						'options' => array(
							'_self'		=> '_self',
							'_blank'	=> '_blank',
							'_parent'	=> '_parent',
							'_top'		=> '_top'
						)
					)
				)
            )
        );
		return $this->getFormSection($fields_form, 'Testimonials Settings', $tab_name);
	}
	protected function ourbrandSettings($tab_name) {
		$fields_form = array(
			$this->field_onOff('TSP_SBE_OURBRAND_STATUS', 'Enabled'),
			$this->field_text ('TSP_SBE_OURBRAND_TITLE', 'Title', 'fixed-width-xl', true),
			$this->field_textarea ('TSP_SBE_OURBRAND_DESC', 'Description', '', true),
            array(
                'label' => $this->l('Our brands'),
                'name' => 'TSP_SBE_OURBRANDS',
            	'lang' => true,
				'type' => 'additem',
				'btn' => $this->l('Add Brand'),
				'data' => $this->getAdditemData('TSP_SBE_OURBRANDS'),
				'fields' => array(
					array(
						'label' => $this->l('Title'),
						'name' => 'title',
						'type' => 'text',
						'width' => '2'
					),
					array(
						'label' => $this->l('Link'),
						'name' => 'link',
						'type' => 'text',
						'width' => '3'
					),
					array(
						'label' => $this->l('Target'),
						'name' => 'target',
						'type' => 'select',
						'width' => '1',
						'options' => array(
							'_self'		=> '_self',
							'_blank'	=> '_blank',
							'_parent'	=> '_parent',
							'_top'		=> '_top'
						)
					),
					array(
						'label' => $this->l('Logo'),
						'name' => 'logo',
						'type' => 'image',
						'width' => '4'
					),
				)
            )
        );
		return $this->getFormSection($fields_form, 'Our brands Settings', $tab_name);
	}
	protected function eventsSettings($tab_name) {
		$fields_form = array(
			$this->field_onOff('TSP_SBE_EVENTS_STATUS', 'Enabled'),
			$this->field_text ('TSP_SBE_EVENTS_TITLE', 'Title', 'fixed-width-xl', true),
			$this->field_textarea ('TSP_SBE_EVENTS_DESC', 'Description', '', true),
            array(
                'label' => $this->l('Our brands'),
                'name' => 'TSP_SBE_EVENTS',
            	'lang' => true,
				'type' => 'additem',
				'btn' => $this->l('Add Brand'),
				'data' => $this->getAdditemData('TSP_SBE_EVENTS'),
				'fields' => array(
					array(
						'label' => $this->l('Desc'),
						'name' => 'desc',
						'type' => 'textarea',
						'width' => '7'
					),
					array(
						'label' => $this->l('Link'),
						'name' => 'link',
						'type' => 'text',
						'width' => '3'
					),
				)
            )
        );
		return $this->getFormSection($fields_form, 'Our brands Settings', $tab_name);
	}
	protected function advanceSettings($tab_name) {
		$fields_form = array(
			array(
				'type' => 'select',
                'label' => $this->l('SCSS Compile'),
				'name' => 'TSP_SBE_SCSSCOMPILE',
				'options' => array(
					'query' => array(
						array('id' => 1, 'name' => 'Alway compile'),
						array('id' => 2, 'name' => 'Only compile when don\'t have the css file')
					),
					'id' => 'id',
					'name' => 'name'
				)
			),
			array(
				'type' => 'select',
                'label' => $this->l('CSS Format'),
				'name' => 'TSP_SBE_SCSSFORMAT',
				'options' => array(
					'query' => array(
						array('id' => 'scss_formatter', 'name' => 'scss_formatter'),
						array('id' => 'scss_formatter_nested', 'name' => 'scss_formatter_nested'),
						array('id' => 'scss_formatter_compressed', 'name' => 'scss_formatter_compressed')
					),
					'id' => 'id',
					'name' => 'name'
				)
			),
			array(
				'type' => 'btn_clearcss',
				'name' => 'btn_clearcss'
			),
			$this->field_onOff('TSP_SBE_OFFTRANSITIONS', 'Disabled CSS Transitions'),
			$this->field_onOff('TSP_SBE_SHOWCPANEL', 'Show cpanel'),
			$this->field_onOff('TSP_SBE_SHOWTOOLTIP', 'Show tool tip'),
			array(
				'type' => 'export_cfg',
				'name' => 'export_cfg'
			),
			array(
				'type' => 'inport_cfg',
				'name' => 'inport_cfg'
			),
        );
		return $this->getFormSection($fields_form, 'Advance settings', $tab_name);
	}
	protected function customCssJsSetting($tab_name) {
		$fields_form = array(
			array(
                'type' => 'css_editor',
                'label' => $this->l('Custom Css'),
                'name' => 'TSP_SBE_CUSTOMCSS',
			),
			array(
                'type' => 'js_editor',
                'label' => $this->l('Custom Js'),
                'name' => 'TSP_SBE_CUSTOMJS',
			)
        );
		return $this->getFormSection($fields_form, 'Custom CSS, JS Setting', $tab_name);
	}
	protected function field_textarea ($name, $label, $class = '', $lang = false, $editor = false, $hint = '') {
		$field = array ();
		$field['type'] = 'textarea';
		$field['label'] = $this->l($label);
		$field['name'] = $name;
		$field['import_export'] = true;
		if($class) $field['class'] = $class;
		if($lang) $field['lang'] = $lang;
		if($editor) $field['autoload_rte'] = $editor;
		if($hint) $field['hint'] = $this->l($hint);
		
		return $field;
	}
	protected function field_text ($name, $label, $class = '', $lang = false, $hint = '') {
		$field = array ();
		$field['type'] = 'text';
		$field['label'] = $this->l($label);
		$field['name'] = $name;
		if($class) $field['class'] = $class;
		if($lang) $field['lang'] = $lang;
		if($hint) $field['hint'] = $this->l($hint);
		
		return $field;
	}
	protected function field_onOff ($name, $label) {
		return array(
			'type' => 'switch',
			'label' => $this->l($label),
			'name' => $name,
			'values' => array(
				array(
					'id' => $name.'_ON',
					'value' => 1,
					'label' => $this->l('Enabled')
				),
				array(
					'id' => $name.'_OFF',
					'value' => 0,
					'label' => $this->l('Disabled')
				)
			)
		);
	}
	protected function getFormSection ($fields_form, $title, $tab_name, $icon = 'icon-cogs') {
		return array(
			'form' => array(
				'legend' => array(
					'title' => $title,
					'icon' => $icon
				),
				'input' => $fields_form,
				'buttons' => array(
					array(
						'title' => $this->l('Save'),
						'name' => $tab_name,
						'id' => $tab_name,
						'class' => 'btn btn-default pull-right btn-section-submit',
						'icon' => 'process-icon-save'
					)
				),
				'submit' => array(
					'title' => $this->l('Save All')
				)
			)
		);
	}
	public function randColor($colors = null, $min = 0, $max = 255) {
		if($colors != null) {
			$colorArr = explode(',', $colors);
			foreach($colorArr as $k => $color) {
				$color = str_replace(' ', '', trim($color));
				if(preg_match('/^#[a-f0-9]{6}$|^#[a-f0-9]{3}$/i', $color)) $colorArr[$k] = strtolower($color);
				else unset($colorArr[$k]);
			}
			if(count($colorArr)) {
				$rand_key = array_rand($colorArr, 1);
				return $colorArr[$rand_key];
			}
			
			$colorArr = explode(',', $colors);
			foreach($colorArr as $k => $color) {
				$color = str_replace(' ', '', trim($color));
				if(is_int($color)) $colorArr[$k] = $color;
				else unset($colorArr[$k]);
			}
			if(count($colorArr)) {
				if($colorArr[0] < $colorArr[1]) {
					$min = $colorArr[0];
					$max = $colorArr[1];
				} else {
					$min = $colorArr[1];
					$max = $colorArr[0];
				}
			}
		}
		$color = '#';
		$color .= str_pad( dechex( mt_rand( $min, $max ) ), 2, '0', STR_PAD_LEFT);
		$color .= str_pad( dechex( mt_rand( $min, $max ) ), 2, '0', STR_PAD_LEFT);
		$color .= str_pad( dechex( mt_rand( $min, $max ) ), 2, '0', STR_PAD_LEFT);
		return $color;
	}
    protected function _createTab() {
        $response = true;
        $parentTabID = Tab::getIdFromClassName('AdminTSP');
        if ($parentTabID) {
            $parentTab = new Tab($parentTabID);
        } else {
            $parentTab = new Tab();
            $parentTab->active = 1;
            $parentTab->name = array();
            $parentTab->class_name = "AdminTSP";
            foreach (Language::getLanguages() as $lang){
                $parentTab->name[$lang['id_lang']] = "TPL Solution";
            }
            $parentTab->id_parent = 0;
            $parentTab->module = $this->name;
            $response &= $parentTab->add();
        }
        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = "AdminTSPSobieTheme";
        $tab->name = array();
        foreach (Language::getLanguages() as $lang){
            $tab->name[$lang['id_lang']] = "TSP Sobie theme";
        }
        $tab->id_parent = $parentTab->id;
        $tab->module = $this->name;
        $response &= $tab->add();
        return $response;
    }
    protected function _deleteTab() {
        $id_tab = Tab::getIdFromClassName('AdminTSPSobieTheme');
        $parentTabID = Tab::getIdFromClassName('AdminTSP');
        $tab = new Tab($id_tab);
        $tab->delete();
        $tabCount = Tab::getNbTabs($parentTabID);
        if ($tabCount == 0) {
            $parentTab = new Tab($parentTabID);
            $parentTab->delete();
        }
        return true;
    }
	public static function updateValue($key, $values, $html = false, $id_shop_group = null, $id_shop = null)
	{
		if (!Validate::isConfigName($key))
			die(sprintf(Tools::displayError('[%s] is not a valid configuration key'), $key));
		if ($id_shop === null || !Shop::isFeatureActive())
			$id_shop = Shop::getContextShopID(true);
		if ($id_shop_group === null || !Shop::isFeatureActive())
			$id_shop_group = Shop::getContextShopGroupID(true);

		if (!is_array($values))
			$values = array($values);

//		if ($html)
//			foreach ($values as $lang => $value)
//				$values[$lang] = Tools::purifyHTML($value);
		$result = true;
		foreach ($values as $lang => $value)
		{
			$stored_value = Configuration::get($key, $lang, $id_shop_group, $id_shop);
			if ((!is_numeric($value) && $value === $stored_value) || (is_numeric($value) && $value == $stored_value && Configuration::hasKey($key, $lang)))
				continue;
			if (Configuration::hasKey($key, $lang, $id_shop_group, $id_shop))
			{
				if (!$lang)
				{
					$result &= Db::getInstance()->update('configuration', array(
						'value' => pSQL($value, $html),
						'date_upd' => date('Y-m-d H:i:s'),
					), '`name` = \''.pSQL($key).'\''.TSPSobieCore::sqlRestriction($id_shop_group, $id_shop), 1, true);
				}
				else
				{
					$sql = 'UPDATE `'._DB_PREFIX_.bqSQL('configuration').'_lang` cl
							SET cl.value = \''.pSQL($value, $html).'\',
								cl.date_upd = NOW()
							WHERE cl.id_lang = '.(int)$lang.'
								AND cl.`'.bqSQL('id_configuration').'` = (
									SELECT c.`'.bqSQL('id_configuration').'`
									FROM `'._DB_PREFIX_.bqSQL('configuration').'` c
									WHERE c.name = \''.pSQL($key).'\''
										.TSPSobieCore::sqlRestriction($id_shop_group, $id_shop)
								.')';
					$result &= Db::getInstance()->execute($sql);
				}
			}
			else
			{
				if (!$configID = Configuration::getIdByName($key, $id_shop_group, $id_shop))
				{
					$newConfig = new Configuration();
					$newConfig->name = $key;
					if ($id_shop)
						$newConfig->id_shop = (int)$id_shop;
					if ($id_shop_group)
						$newConfig->id_shop_group = (int)$id_shop_group;
					if (!$lang)
						$newConfig->value = $value;
					$result &= $newConfig->add(true, true);
					$configID = $newConfig->id;
				}

				if ($lang)
				{
					$result &= Db::getInstance()->insert('configuration_lang', array(
						'id_configuration' => $configID,
						'id_lang' => (int)$lang,
						'value' => pSQL($value, $html),
						'date_upd' => date('Y-m-d H:i:s'),
					));
				}
			}
		}
		Configuration::set($key, $values, $id_shop_group, $id_shop);
		return $result;
	}
	protected static function sqlRestriction($id_shop_group, $id_shop) {
		if ($id_shop)
			return ' AND id_shop = '.(int)$id_shop;
		elseif ($id_shop_group)
			return ' AND id_shop_group = '.(int)$id_shop_group.' AND (id_shop IS NULL OR id_shop = 0)';
		else
			return ' AND (id_shop_group IS NULL OR id_shop_group = 0) AND (id_shop IS NULL OR id_shop = 0)';
	}
	public function clearCacheTPL() {
		$tpls_dir = dirname(__FILE__) . DS . 'views' . DS . 'templates' . DS . 'hook' . DS;
		$tpls = glob($tpls_dir.'*.tpl');
		foreach($tpls as $tpl) {
			parent::_clearCache(str_replace($tpls_dir, '', $tpl));
		}
	}
}
?>
