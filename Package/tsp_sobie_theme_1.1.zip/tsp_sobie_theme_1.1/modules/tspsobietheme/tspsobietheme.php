<?php
/**
* 2015 Tpl Solution
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
*  @author    Tpl Solution <contact@tplsolution.com>
*  @copyright 2015 Tpl Solution
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of Tpl Solution
*/

if (!defined('_PS_VERSION_')) exit;
include_once(dirname(__FILE__) . '/tspsobiecore.php');
include_once(dirname(__FILE__) . '/tspsobiesmartcodes.php');

class TSPSobieTheme extends TSPSobieCore {
	// smart codes
    public static $static_shortcode_tags = array();
    public static $tsp_current_hook = '';
	// end smart codes
	
	public function __construct() {
		$this->name = 'tspsobietheme';
		$this->tab = 'home';
		$this->version = '1.1';
		$this->author = 'TPL Solution';
		$this->need_instance = 0;
		$this->ps_versions_compliancy = array('min' => '1.6', 'max' => '1.6');
		$this->bootstrap = true;

		parent::__construct();

		$this->displayName = $this->l('TSP Sobie Theme');
		$this->description = $this->l('Config params of theme');
		$this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
	}
	public function install($delete_params = true) {
		if (Shop::isFeatureActive())
	    	Shop::setContext(Shop::CONTEXT_ALL);
	 
	  	if (!parent::install() 
	  		|| !$this->registerHook('header')
	  		|| !$this->registerHook('displayBackOfficeHeader')
	  		|| !$this->registerHook('displayBackOfficeFooter')
			|| !$this->registerHook('actionAdminControllerSetMedia')
			|| !$this->registerHook('actionOrderStatusPostUpdate')
			|| !$this->registerHook('addproduct')
			|| !$this->registerHook('updateproduct')
			|| !$this->registerHook('deleteproduct')
			|| !$this->registerHook('displaySecondImage')
			|| !$this->registerHook('displayIcon')
			|| !$this->registerHook('displaySlideshow')
			|| !$this->registerHook('displayHome')
			
			|| !$this->registerHook('displayOurbrands')
			|| !$this->registerHook('displayEvents')
			|| !$this->registerHook('displayTestimonials')
			|| !$this->registerHook('displaySocials')
			|| !$this->registerHook('displayFooterlinks')
			|| !$this->registerHook('displayContactUs')
			|| !$this->registerHook('displayBusinessHours')
			|| !$this->registerHook('displayDealsProducts')
	  		)
	    	return false;

	  	Configuration::updateValue('PS_USE_HTMLPURIFIER', '0');
	  	Configuration::updateValue('PS_NAVIGATION_PIPE', '>');
	  	Configuration::updateValue('PS_DISABLE_NON_NATIVE_MODULE', '0');
	  	Configuration::updateValue('PS_DISABLE_OVERRIDES', '0');
	  	
	  	
	  	// Activate every option by default
	  	if ($delete_params) $this->installFixtures();
		
		$this->_createTab();
	  	return true;
	}
	public function uninstall($delete_params = true) {
  		foreach($this->themeFields as $key => $value) {
  			if ($delete_params) Configuration::deleteByName($key);
		}
	    $this->_deleteTab();
	    return parent::uninstall();
	}
	public function reset()
	{
		if (!$this->uninstall(false))
			return false;
		if (!$this->install(false))
			return false;

		return true;
	}
	public function hookActionAdminControllerSetMedia($params) {
		$this->context->controller->addCSS(__PS_BASE_URI__ . 'modules/'.$this->name.'/assets/admin/css/tsp-styles.css', 'all');
	}
	public function hookDisplayBackOfficeHeader($params) {
		$this->addModMedia();
	}
	public function hookDisplayBackOfficeFooter() {
		$this->smarty->assign(
			array(
				'categories' => Category::getAllCategoriesName()
			)
		);
		return $this->display(__FILE__, 'tspbtpl.tpl', $this->getCacheId());
	}
	public function hookDisplaySlideshow($params) {
		if(!Configuration::get('TSP_SBE_SLSTATUS')) return;
		
		global $cookie;
		
		$width = ((int)Configuration::get('TSP_SBE_SLWIDTH')) ? (int)Configuration::get('TSP_SBE_SLWIDTH') : 1200;
		$height = ((int)Configuration::get('TSP_SBE_SLHEIGHT')) ? (int)Configuration::get('TSP_SBE_SLHEIGHT') : 580;
		$imgs = $this->tspUnSerialize(Configuration::get('TSP_SBE_SLIMGS', $this->context->language->id));
		
		if($cookie->__isset('TSP_SBECP_DEMO') && (int)$cookie->__get('TSP_SBECP_DEMO') == 3) {
			$width = 770;
			$height = 510;
			$imgs = $this->tspUnSerialize('a:2:{s:31:"_144360798798009247773254755884";a:3:{s:5:"title";s:12:"TPL Solution";s:4:"link";s:1:"#";s:3:"img";s:49:"__TSPPS_BASE_URI__themes/tsp_sobie/images/sl3.jpg";}s:31:"_144360803306404532126223202795";a:3:{s:5:"title";s:12:"TPL Solution";s:4:"link";s:1:"#";s:3:"img";s:49:"__TSPPS_BASE_URI__themes/tsp_sobie/images/sl4.jpg";}}');
		}
		
		if(!file_exists(dirname(__FILE__) . '/cache/'.$width.'x'.$height.'.png')) {
	        $image = imagecreate($width, $height);
	        $white = imagecolorallocate($image, 255, 255, 255);
			imagecolortransparent($image, $white);
	        imagepng($image, dirname(__FILE__) . '/cache/'.$width.'x'.$height.'.png');
	        imagedestroy($image);
        }
		if (!$this->isCached('displaySlideshow.tpl', $this->getCacheId())){
			$auto = ((int)Configuration::get('TSP_SBE_SLAUTO')) ? (int)Configuration::get('TSP_SBE_SLAUTO') : false;
			$animateIn = Configuration::get('TSP_SBE_SLANIMATEIN');
			$animateOut = Configuration::get('TSP_SBE_ANIMATEOUT');
			$this->smarty->assign(array(
				'imgs' => $imgs,
				'auto' => $auto,
				'animateIn' => $animateIn,
				'animateOut' => $animateOut,
				'bg' => __PS_BASE_URI__ . 'modules/'.$this->name.'/cache/'.$width.'x'.$height.'.png',
			));
		}
		return $this->display(__FILE__, 'displaySlideshow.tpl', $this->getCacheId());
	}
	public function getProducts($params, $source, $nb) {
		$id_lang = $this->context->language->id;
		if (!Configuration::get('PS_CATALOG_MODE')) {
			$products = array();
			if($source == 'deals') {
				$products = TSPSobieProduct::getDealsProducts($id_lang, 0, $nb);
			} elseif ($source == 'specials') {
				$products = Product::getPricesDrop($id_lang, 0, $nb);
			} elseif ($source == 'viewed') {
				$products = TSPSobieProduct::getViewedProduct($params, $id_lang, 0, $nb);
			} elseif ($source == 'topsale') {
				$products = ProductSale::getBestSalesLight($id_lang, 0, $nb);
			} elseif ($source == 'new') {
				$products = TSPSobieProduct::getNewProducts(Configuration::get('PS_NB_DAYS_NEW_PRODUCT'), $id_lang, 0, $nb);
			} elseif ((int)$source) {
				$category = new Category($source, $id_lang);
				$products = $category->getProducts($id_lang, 0, $nb, $params['orderby'], $params['orderway']);
			} else {
				$products = Product::getProductsProperties($id_lang, Product::getProducts($id_lang, 0, $nb, 'date_add', 'ASC'));
			}
			
			$list = array();
			if ($products && count($products)) {
				$font = new FrontController;
				$font->addColorsToProductList($products);
				foreach ($products as $product)
				{
					$obj     = new Product((int) ($product['id_product']), false, $this->context->language->id);
					$images  = $obj->getImages($this->context->language->id);
					$_images = array();
					$id_image = '';
					$id_image2 = '';
					if (!empty($images)) {
						foreach ($images as $k => $image) {
							if($image['cover']) {
								$id_image = $obj->id . '-' . $image['id_image'];
							} else {
								$_images[] = $obj->id . '-' . $image['id_image'];
							}
						}
						if($id_image == '') {
							$id_image = $_images[0];
							if(isset($_images[1])) $id_image2 = $_images[1];
						} else {
							$id_image2 = $_images[0];
						}
					} else {
						$id_image = $this->context->language->iso_code.'-default';
						$id_image2 = $this->context->language->iso_code.'-default';
					}

					$product['id_image'] = $id_image;
					$product['id_image2'] = $id_image2;
					$list[] = $product;
				}
			}
			return array(
					'homeSize' => Image::getSize(ImageType::getFormatedName('home')),
					'products' => $list
				);
		}
	}
	public function hookDisplayIcon($params) {
		if(!isset($params['icon'])) return;
		if($params['icon'] == 'compare') {
			$icon = 'fa-exchange';
			$icon = $this->getThemeCfg(array('f' => 'TSP_SBE_ICOCOMPARE'));
			return '<i class="fa '.$icon.'"></i>';
		}
		if($params['icon'] == 'quickview') {
			$icon = 'fa-expand';
			$icon = $this->getThemeCfg(array('f' => 'TSP_SBE_ICOQUICKVIEW'));
			return '<i class="fa '.$icon.'"></i>';
		}
		if($params['icon'] == 'cart') {
			$icon = 'fa-cart-arrow-down';
			$icon = $this->getThemeCfg(array('f' => 'TSP_SBE_ICOCART'));
			return '<i class="fa '.$icon.'"></i>';
		}
		if($params['icon'] == 'wishlist') {
			$icon = 'fa-heart-o';
			$icon = $this->getThemeCfg(array('f' => 'TSP_SBE_ICOWISHLIST'));
			return '<i class="fa '.$icon.'"></i>';
		}
	}
	public function hookDisplaySecondImage($params) {
		if (!$this->isCached('displaySecondImage.tpl', $this->getCacheId($params['id_product']))) {
			$id_lang = $this->context->language->id;
			$obj     = new Product((int) ($params['id_product']), false, $id_lang);
			$images  = $obj->getImages($this->context->language->id);
			$_images = array();
			if (!empty($images)) {
				foreach ($images as $k => $image) {
					if($image['cover']){
						$_images['cover'] = $obj->id . '-' . $image['id_image'];
					} else {
						$_images['second'] = $obj->id . '-' . $image['id_image'];
					}
					if(
						isset($_images['cover']) && $_images['cover']
						&& isset($_images['second']) && $_images['second']
						) break;
				}
			} else {
				$_images['cover'] = $this->context->language->iso_code.'-default';
			}
			
			$this->smarty->assign(array(
				'link_rewrite' => $params['link_rewrite'],
				'images' => $_images,
				'secon_img' => Configuration::get('TSP_SBE_SECONDIMG')
			));
		}
		return $this->display(__FILE__, 'displaySecondImage.tpl', $this->getCacheId($params['id_product']));
	}
	private function getCurrentProduct($products, $id_current)
	{
		if ($products)
		{
			foreach ($products as $key => $product)
			{
				if ($product['id_product'] == $id_current)
					return $key;
			}
		}

		return false;
	}
	public function parse($str) {
		$smartcodes = new TSPSobieSmartCodes;
		return $smartcodes->parse($str);
	}
	public function hookDisplayHome($params) {
		if (!$this->isCached('block-homepage.tpl', $this->getCacheId())) {
		//	$this->registerHook('displayOurbrands');
			$html = $this->getThemeCfg(array('f' => 'TSP_SBE_HOMEPAGE_TSPB'));
	//		$html = preg_replace('/\n/s', '', $html);
	//		$html = preg_replace('/\t/s', '', $html);
			$html = preg_replace('/<div data-backend(.*?)>/s', '', $html);
			$html = preg_replace('/<div><\/div>/', '', $html);
			$html = preg_replace('/id=""/', '', $html);
	//		$html = preg_replace('/<!-- backend -->(.*?)<!-- \/backend -->/s', '', $html);
			//$html = preg_replace('/<(.*?)><!-- backendlt -->/s', '', $html);
			//$html = preg_replace('/<!-- backendgt --><\/(.*?)>/s', '', $html);
		//	var_dump($html); die;
			$this->smarty->assign(array(
				'content' => $html,
			));
		}
		return $this->display(__FILE__, 'block-homepage.tpl', $this->getCacheId());
	}
	public function hookDisplayTestimonials($params) {
		if(!$this->getThemeCfg(array('f' => 'TSP_SBE_TESTIMONIAL_STATUS'))) return;
		$cache_id = 'hookDisplayTestimonials';
		if (!$this->isCached('displayTestimonials.tpl', $this->getCacheId($cache_id))) {
			$TESTIMONIAL_TITLE = $this->getThemeCfg(array('f' => 'TSP_SBE_TESTIMONIAL_TITLE'));
			if($TESTIMONIAL_TITLE) {
				$titles = explode('|', $TESTIMONIAL_TITLE);
				if(count($titles) > 1) {
					$sub_title = $titles[1];
					$title = $titles[0];
				} else {
					$sub_title = '';
					$title = $titles[0];
				}
			}
			$this->smarty->assign(array(
				'TITLE' => $title,
				'SUB_TITLE' => $sub_title,
				'TSP_SBE_TESTIMONIAL_TITLE' => $this->getThemeCfg(array('f' => 'TSP_SBE_TESTIMONIAL_TITLE')),
				'TSP_SBE_TESTIMONIAL_DESC' => $this->getThemeCfg(array('f' => 'TSP_SBE_TESTIMONIAL_DESC')),
				'TSP_SBE_TESTIMONIALS' => $this->getThemeCfg(array('f' => 'TSP_SBE_TESTIMONIALS')),
			));
		}
		return $this->display(__FILE__, 'displayTestimonials.tpl', $this->getCacheId($cache_id));
	}
	public function hookDisplaySocials($params) {
		if(!$this->getThemeCfg(array('f' => 'TSP_SBE_SOCIAL_STATUS'))) return;
		$cache_id = 'hookDisplaySocials';
		if (!$this->isCached('displaySocials.tpl', $this->getCacheId($cache_id))) {
			$this->smarty->assign(array(
				'TSP_SBE_SOCIAL_TITLE' => $this->getThemeCfg(array('f' => 'TSP_SBE_SOCIAL_TITLE')),
				'TSP_SBE_SOCIAL' => $this->getThemeCfg(array('f' => 'TSP_SBE_SOCIAL')),
			));
		}
		return $this->display(__FILE__, 'displaySocials.tpl', $this->getCacheId($cache_id));
	}
	public function hookDisplayOurbrands($params) {
		if(!$this->getThemeCfg(array('f' => 'TSP_SBE_OURBRAND_STATUS'))) return;
		$cache_id = 'hookDisplayOurbrands';
		if (!$this->isCached('displayOurbrands.tpl', $this->getCacheId($cache_id))) {
			$OURBRAND_TITLE = $this->getThemeCfg(array('f' => 'TSP_SBE_OURBRAND_TITLE'));
			if($OURBRAND_TITLE) {
				$titles = explode('|', $OURBRAND_TITLE);
				if(count($titles) > 1) {
					$sub_title = $titles[1];
					$title = $titles[0];
				} else {
					$sub_title = '';
					$title = $titles[0];
				}
			}
			$this->smarty->assign(array(
				'TITLE' => $title,
				'SUB_TITLE' => $sub_title,
				'TSP_SBE_OURBRAND_DESC' => $this->getThemeCfg(array('f' => 'TSP_SBE_OURBRAND_DESC')),
				'TSP_SBE_OURBRANDS' => $this->getThemeCfg(array('f' => 'TSP_SBE_OURBRANDS')),
			));
		}
		return $this->display(__FILE__, 'displayOurbrands.tpl', $this->getCacheId($cache_id));
	}
	public function hookDisplayEvents($params) {
		if(!$this->getThemeCfg(array('f' => 'TSP_SBE_EVENTS_STATUS'))) return;
		$cache_id = 'hookDisplayEvents';
		if (!$this->isCached('displayEvents.tpl', $this->getCacheId($cache_id))) {
			$EVENTS_TITLE = $this->getThemeCfg(array('f' => 'TSP_SBE_EVENTS_TITLE'));
			if($EVENTS_TITLE) {
				$titles = explode('|', $EVENTS_TITLE);
				if(count($titles) > 1) {
					$sub_title = $titles[1];
					$title = $titles[0];
				} else {
					$sub_title = '';
					$title = $titles[0];
				}
			}
			$this->smarty->assign(array(
				'TITLE' => $title,
				'SUB_TITLE' => $sub_title,
				'TSP_SBE_EVENTS_DESC' => $this->getThemeCfg(array('f' => 'TSP_SBE_EVENTS_DESC')),
				'TSP_SBE_EVENTS' => $this->getThemeCfg(array('f' => 'TSP_SBE_EVENTS')),
			));
		}
		return $this->display(__FILE__, 'displayEvents.tpl', $this->getCacheId($cache_id));
	}
	public function hookDisplayFooterlinks($params) {
		$cache_id = 'hookDisplayFooterlinks';
		if (!$this->isCached('displayFooterlinks.tpl', $this->getCacheId($cache_id))) {
			$this->smarty->assign(array(
				'TSP_SBE_FOOTERLINKS' => $this->getThemeCfg(array('f' => 'TSP_SBE_FOOTERLINKS')),
			));
		}
		return $this->display(__FILE__, 'displayFooterlinks.tpl', $this->getCacheId($cache_id));
	}
	public function getHTTP() {
		if (!empty($_SERVER['HTTPS']) && ('on' == $_SERVER['HTTPS'])) return 'https://';
		else return 'http://';
	}
	public function getThemeCfg($params) {
		if(!isset($params['f'])) return;
		
		if(isset($params['s']) && $params['s'] == 'ps') {
			return Configuration::get($params['f']);
		}
		
		
		global $cookie, $smarty;
		
		$field_name = $params['f'];
		$field = $this->themeFields[$field_name];
		$field_value = '';
		if($field['lang']) {
			if(is_bool(Configuration::get($field_name, $this->context->language->id))) {
				if($field['type'] == 'additem') $field_value = Configuration::get($field_name, Configuration::get('PS_LANG_DEFAULT'));
				else $field_value = Configuration::get($field_name, Configuration::get('PS_LANG_DEFAULT'));
			} else {
				if($field['type'] == 'additem') $field_value = Configuration::get($field_name, $this->context->language->id);
				else $field_value = Configuration::get($field_name, $this->context->language->id);
			}
		} else $field_value = Configuration::get($field_name);
		
		if($field['type'] == 'additem') $field_value = $this->tspUnSerialize($field_value);
		else $field_value = $this->parse($this->TSPClass->replaceLinkContent($field_value, true));

		if(Configuration::get('TSP_SBE_SHOWCPANEL')) {
			if($cookie->__get(str_replace('TSP_SBE_', 'TSP_SBECP_', $field_name)))
				$field_value = $cookie->__get( str_replace('TSP_SBE_', 'TSP_SBECP_', $field_name));
			
			// demo
			$demo_layout = false;
			if($cookie->__isset('TSP_SBECP_DEMO') && (int)$cookie->__get('TSP_SBECP_DEMO')) $demo_layout = (int)$cookie->__get('TSP_SBECP_DEMO');
			if($demo_layout){
	            $cpanel_action = false;
				if($cookie->__isset('TSP_SBECP_ACTION') && (int)$cookie->__get('TSP_SBECP_ACTION')) $cpanel_action = (int)$cookie->__get('TSP_SBECP_ACTION');
				if ($demo_layout == 32343243) {
					if($params['f'] == 'TSP_SBE_WRAPPERWIDTH' && !$cpanel_action) $field_value = '1240';
					if($params['f'] == 'TSP_SBE_THEMECOLOR' && !$cpanel_action) $field_value = '#f74c70';
					if($params['f'] == 'TSP_SBE_HOMEPAGE') {
						$field_value = '<div class="tsp-smartcode">[emptyspace height="30"][/emptyspace]</div><div class="tsp-smartcode">[wrapper container="1"]<div class="row"><div class="col-sm-8"><div id="tsp_slideshow">[hook h="displaySlideshow"][/hook]</div></div><div class="visible-xs">[emptyspace height="30"][/emptyspace]</div><div class="col-sm-4"><div class="row"><div class="col-sm-12 col-xs-6">[banner title="Tpl Solution" link="#" class="" src_1="__TSPPS_BASE_URI__themes/tsp_sobie/images/banner/6.jpg" src_2=""][/banner]<div class="hidden-xs">[emptyspace height="30"][/emptyspace]</div></div><div class="col-sm-12 col-xs-6">[banner title="Tpl Solution" link="#" class="" src_1="__TSPPS_BASE_URI__themes/tsp_sobie/images/banner/7.jpg" src_2=""][/banner]</div></div></div></div>[/wrapper]</div><div class="tsp-smartcode">[emptyspace height="60"][/emptyspace]</div><div class="tsp-smartcode">[wrapper container="1"][hook h="displayTSPProductTabs"][/hook][/wrapper]</div><div class="tsp-smartcode">[emptyspace height="60"][/emptyspace]</div><div class="tsp-smartcode block-spotlight-1">[wrapper container="1" bg_color="#efefef" bg_type="fullwidth"]<div class="div2table"><div class="tr"><div class="td image"><img src="__TSPPS_BASE_URI__themes/tsp_sobie/images/sp1.png" alt="Tpl Solution"></div><div class="td info"><h3 class="highlight">SAVE UP TO 50%</h3><h1>LATER THIS WEEKEND</h1><p>Accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duisdolorte feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihilimperdiet doming id quod mazim placerat me..</p><div class="tsp-smartcode">[emptyspace height="15"][/emptyspace]</div><p><a class="btn btn-default" href="#">LEARN MORE</a><a class="btn btn-default" href="#">Shop Now</a></p></div></div></div>[/wrapper]</div><div class="tsp-smartcode">[emptyspace height="80"][/emptyspace]</div><div class="tsp-smartcode">[wrapper container="1"][prdslider title="Hot Deals" source="deals" limit="6" orderby="name" orderway="ASC" xs="2" sm="2" md="3" lg="3"][/prdslider][/wrapper]</div><div class="tsp-smartcode">[emptyspace height="55"][/emptyspace]</div><div class="container"><div class="row"><div class="col-sm-6">[banner title="Tpl Solution" link="#" class="" src_1="__TSPPS_BASE_URI__themes/tsp_sobie/images/banner/8.jpg" src_2=""][/banner]</div><div class="col-sm-6">[banner title="Tpl Solution" link="#" class="" src_1="__TSPPS_BASE_URI__themes/tsp_sobie/images/banner/9.jpg" src_2=""][/banner]</div></div></div><div class="tsp-smartcode">[emptyspace height="60"][/emptyspace]</div><div class="tsp-smartcode">[wrapper container="1"][prdblock title="SPECIAL OFFERS" source="new" limit="6" orderby="name" orderway="ASC" lg="3" md="3" sm="2" xs="1"][/prdblock][/wrapper]</div><div class="tsp-smartcode">[emptyspace height="30"][/emptyspace]</div><div class="tsp-smartcode">[wrapper container="0" bg_color="#1f1f1f" bg_image="__TSPPS_BASE_URI__themes/tsp_sobie/images/bg_2.jpg" text_style="light" bg_type="fullwidth" bg_repeat="no-repeat" bg_attachment="fixed" bg_position="center center" bg_size="cover"][hook h="displayTestimonials" ][/hook][/wrapper]</div><div class="tsp-smartcode">[emptyspace height="60"][/emptyspace]</div><div class="tsp-smartcode">[hook h="displayLatestblog"][/hook]</div><div class="tsp-smartcode">[emptyspace height="60"][/emptyspace]</div>';
						$field_value = $this->parse($this->TSPClass->replaceLinkContent($field_value, true));
					}
				}
			}
			// end demo
		}
		
		return $field_value;
	}
    public function getStores() {
        $stores = Db::getInstance()->executeS('
		SELECT s.*, cl.name country, st.iso_code state
		FROM '._DB_PREFIX_.'store s
		'.Shop::addSqlAssociation('store', 's').'
		LEFT JOIN '._DB_PREFIX_.'country_lang cl ON (cl.id_country = s.id_country)
		LEFT JOIN '._DB_PREFIX_.'state st ON (st.id_state = s.id_state)
		WHERE s.active = 1 AND cl.id_lang = '.(int)$this->context->language->id);
        return $stores;
    }
    public function getStore($id_store = 1) {
        $stores = Db::getInstance()->executeS('
		SELECT s.*, cl.name country, st.iso_code state
		FROM '._DB_PREFIX_.'store s
		'.Shop::addSqlAssociation('store', 's').'
		LEFT JOIN '._DB_PREFIX_.'country_lang cl ON (cl.id_country = s.id_country)
		LEFT JOIN '._DB_PREFIX_.'state st ON (st.id_state = s.id_state)
		WHERE s.id_store = '.$id_store.' AND cl.id_lang = '.(int)$this->context->language->id);
        return $stores[0];
    }
	public function hookDisplayBusinessHours($params) {
		$cache_id = 'displayBusinessHours';
		if (!$this->isCached('displayBusinessHours.tpl', $this->getCacheId($cache_id))) {
			$id_store = $this->getThemeCfg(array('f' => 'TSP_SBE_BUSINESSHOUR'));
			$store = $this->getStore($id_store);
			
			$days = array();
	        $days[0] = 'Monday';
	        $days[1] = 'Tuesday';
	        $days[2] = 'Wednesday';
	        $days[3] = 'Thursday';
	        $days[4] = 'Friday';
	        $days[5] = 'Sat';
	        $days[6] = 'Sun';

	        $days_datas = array();
	        $hours = Tools::unSerialize($store['hours']);

			$days_datas[] = array( 'day' => $days[0], 'hours' => $hours[0] );
			$days_datas[] = array( 'day' => $days[1], 'hours' => $hours[1] );
			$days_datas[] = array( 'day' => $days[2], 'hours' => $hours[2] );
			$days_datas[] = array( 'day' => $days[3], 'hours' => $hours[3] );
			$days_datas[] = array( 'day' => $days[4], 'hours' => $hours[4] );
			if($hours[5] == $hours[6]) {
				$days_datas[] = array( 'day' => $days[5] . ' - ' . $days[6], 'hours' => $hours[5] );
			} else {
				$days_datas[] = array( 'day' => $days[5], 'hours' => $hours[5] );
				$days_datas[] = array( 'day' => $days[6], 'hours' => $hours[6] );
			}
			$this->smarty->assign(array(
				'days_datas' => $days_datas
			));
		}
		return $this->display(__FILE__, 'displayBusinessHours.tpl', $this->getCacheId($cache_id));
	}
	public function hookDisplayContactUs($params) {
		$cache_id = 'displayContactUs';
		if (!$this->isCached('displayContactUs.tpl', $this->getCacheId($cache_id))) {
			$id_store = $this->getThemeCfg(array('f' => 'TSP_SBE_CONTACTUS'));
			$store = $this->getStore($id_store);
			$this->smarty->assign(array(
				'store' => $store,
			));
		}
		return $this->display(__FILE__, 'displayContactUs.tpl', $this->getCacheId($cache_id));
	}
	public function hookDisplayDealsProducts($params) {
		$cache_id = 'displayDealsProducts';
		if (!$this->isCached('displayDealsProducts.tpl', $this->getCacheId($cache_id))) {
			$this->smarty->assign($this->getProducts($params, 'deals', 999));
		}
		return $this->display(__FILE__, 'displayDealsProducts.tpl', $this->getCacheId($cache_id));
	}
	
	public function hookHeader($params) {
		global $cookie, $smarty, $cart;
		/*
		$sql = 'SELECT `name` FROM `'._DB_PREFIX_.'configuration` WHERE `value` IS NULL AND `name` like "TSP%"';
		if ($results = Db::getInstance()->ExecuteS($sql)) {
			$languages = Language::getLanguages(false);
			foreach ($results as $field) {
				$values = array();
				foreach ($languages as $lang) {
					$values[$field['name']][(int)$lang['id_lang']] = Configuration::get($field['name'], Configuration::get('PS_LANG_DEFAULT'));
					Configuration::updateValue($field['name'], $values[$field['name']], true);
				}
			}
		}

  		foreach($this->themeFields as $key => $value) {
  			if($value['lang']) {
				$languages = Language::getLanguages(false);
				foreach ($languages as $lang) {
					$values[$key][(int)$lang['id_lang']] = Configuration::get($key, Configuration::get('PS_LANG_DEFAULT'));
					Configuration::updateValue($key, $values[$key], true);
				}
  			}
		}
		*/
	//	$this->clearCacheCss();
		
		$TSP_SBE_SHOWCPANEL = Configuration::get('TSP_SBE_SHOWCPANEL');
		if($TSP_SBE_SHOWCPANEL){
			// CSS, JS for cpanel
			$this->context->controller->addCSS(__PS_BASE_URI__.'themes/'._THEME_NAME_.'/css/tsp-cpanel.css', 'all');
			$this->context->controller->addCSS(__PS_BASE_URI__.'modules/'.$this->name.'/assets/front/css/jquery.miniColors.css', 'all');
			$this->context->controller->addJS(__PS_BASE_URI__.'modules/'.$this->name.'/assets/front/js/jquery.miniColors.min.js', 'all');

			if( Tools::getIsset('TSP_SBECP_APPLY') && strtolower( Tools::getValue('TSP_SBECP_APPLY') ) == "apply" ){
                $cookie->__set('TSP_SBECP_ACTION', true);
		  		foreach($this->themeFields as $key => $value) {
                    if(Tools::getIsset(str_replace('TSP_SBE_', 'TSP_SBECP_', $key))){
                        $cookie->__set(str_replace('TSP_SBE_', 'TSP_SBECP_', $key), Tools::getValue(str_replace('TSP_SBE_', 'TSP_SBECP_', $key)) );
                    }
				}
				Tools::redirect( Tools::getValue('current_url') );
			}
            if( Tools::getIsset('TSP_SBECP_RESET') && strtolower( Tools::getValue('TSP_SBECP_RESET') ) == "reset" ){
                $cookie->__set('TSP_SBECP_ACTION', true);
	  			foreach($this->themeFields as $key => $value) {
					$cookie->__unset(str_replace('TSP_SBE_', 'TSP_SBECP_', $key));
				}
				Tools::redirect( Tools::getValue('current_url') );	
			}

			$demo_layout = false;
			if(Tools::getIsset('TSP_SBECP_DEMO') && (int)Tools::getValue('TSP_SBECP_DEMO')) $demo_layout = (int)Tools::getValue('TSP_SBECP_DEMO');
			if($demo_layout){
				$cookie->__unset('TSP_SBECP_ACTION');
	  			foreach($this->themeFields as $key => $value) {
					$cookie->__unset(str_replace('TSP_SBE_', 'TSP_SBECP_', $key));
				}
                $cookie->__set('TSP_SBECP_DEMO', $demo_layout );
				Tools::redirect(_PS_BASE_URL_.__PS_BASE_URI__);	
			}
			
			
			$this->context->controller->addJS(__PS_BASE_URI__.'themes/'._THEME_NAME_.'/js/tsp-cpanel.js', 'all');
			$smarty->assign(array(
				'TSP_FONTSLIST'				=> $this->getFontsList(),
				'TSP_SBE_PATTERN'				=> $this->getPatternsHTML(true, $this->getThemeCfg(array('f' => 'TSP_SBE_BODYIMG'))),
			));
		}
		
		$font1 		= $this->getThemeCfg(array('f' => 'TSP_SBE_FONT1'));
		$font2 		= $this->getThemeCfg(array('f' => 'TSP_SBE_FONT2'));
		$font3 		= $this->getThemeCfg(array('f' => 'TSP_SBE_FONT3'));
		
		$font2Target 		= $this->getThemeCfg(array('f' => 'TSP_SBE_FONT2TARGETS'));
		$font3Target 		= $this->getThemeCfg(array('f' => 'TSP_SBE_FONT3TARGETS'));
		
		
		$TSP_SBE_FONTSIZE   		= $this->getThemeCfg(array('f' => 'TSP_SBE_FONTSIZE'));
		$TSP_SBE_BODYCOLOR  		= $this->getThemeCfg(array('f' => 'TSP_SBE_BODYCOLOR'));
		$TSP_SBE_BODYIMG    		= $this->getThemeCfg(array('f' => 'TSP_SBE_BODYIMG'));
		
		$font1 = explode(':', $font1);
		$font2 = explode(':', $font2);
		$font3 = explode(':', $font3);
		
		$gfonts = '';
		$fonts_css = '';
		if(isset($font1[0]) && $font1[0]) {
			if($font1[0] == 'GF') {
				if($gfonts != '') $gfonts .= '|';
				$gfonts .= str_replace(' ', '+', $font1[1]);
				$gfonts .= ':' . $font1[2];
				$fonts_css .= 'body{font-family:\''.$font1[1].'\'}';
			} else {
				$fonts_css .= 'body{font-family:'.$font1[0].'}';
			}
		}
		
		if($font2Target && isset($font2[0]) && $font2[0]) {
			if($font1[0] == 'GF') {
				if($gfonts != '') $gfonts .= '|';
				$gfonts .= str_replace(' ', '+', $font2[1]);
				$gfonts .= ':' . $font2[2];
				$fonts_css .= $font2Target.'{font-family:\''.$font2[1].'\'}';
			} else {
				$fonts_css .= $font2Target.'{font-family:'.$font2[0].'}';
			}
		}
		
		if($font3Target && isset($font3[0]) && $font3[0]) {
			if($font1[0] == 'GF') {
				if($gfonts != '') $gfonts .= '|';
				$gfonts .= str_replace(' ', '+', $font3[1]);
				$gfonts .= ':' . $font3[2];
				$fonts_css .= $font3Target.'{font-family:\''.$font3[1].'\'}';
			} else {
				$fonts_css .= $font3Target.'{font-family:'.$font3[0].'}';
			}
		}

		if($gfonts != '') $this->context->controller->addCSS($this->getHTTP().'fonts.googleapis.com/css?family=' . $gfonts, 'all');

		$patternsURL = $this->getBaseUrl().__PS_BASE_URI__."themes/"._THEME_NAME_."/img/patterns/";
		$TSP_SBE_STYLE = '<style type="text/css">';
		$TSP_SBE_STYLE .= 'body{';
		$TSP_SBE_STYLE .= 'font-size:'.$TSP_SBE_FONTSIZE.';';
		$TSP_SBE_STYLE .= 'background-color:'.$TSP_SBE_BODYCOLOR.';';
		$TSP_SBE_STYLE .= 'background-image: url("'.$patternsURL . $TSP_SBE_BODYIMG .'");';
		$TSP_SBE_STYLE .= 'background-position: center top;';
		//$TSP_SBE_STYLE .= 'background-attachment: fixed;;';
		$TSP_SBE_STYLE .= '}';
		$TSP_SBE_STYLE .= $fonts_css;
		
		$TSP_SBE_WRAPPERWIDTH = (int)$this->getThemeCfg(array('f' => 'TSP_SBE_WRAPPERWIDTH'));
		if($TSP_SBE_WRAPPERWIDTH < 1200) $TSP_SBE_WRAPPERWIDTH = 1200;
		$TSP_SBE_STYLE .= '#tsp_wrapper, #tsp_menu {max-width: '.$TSP_SBE_WRAPPERWIDTH.'px}';
		
		$TSP_SBE_STYLE .= $this->getThemeCfg(array('f' => 'TSP_SBE_CUSTOMCSS'));
		$TSP_SBE_STYLE .= '</style>';
		
		$TSP_SBE_SCRIPT = '';
		if($this->getThemeCfg(array('f' => 'TSP_SBE_CUSTOMJS'))) {
			$TSP_SBE_SCRIPT .= '<script>';
			$TSP_SBE_SCRIPT .= $this->getThemeCfg(array('f' => 'TSP_SBE_CUSTOMJS'));
			$TSP_SBE_SCRIPT .= '</script>';
		}
		
		$theme_dir = _PS_ALL_THEMES_DIR_._THEME_NAME_.DS;
		$header_style_cfg = $this->getThemeCfg(array('f' => 'TSP_SBE_HEADER_STYLE'));
		$header_tpl = $theme_dir.$header_style_cfg;
        if(!is_file($header_tpl) || !file_exists($header_tpl)) $header_tpl = $theme_dir.'header-style-1.tpl';
        
		$footer_style_cfg = $this->getThemeCfg(array('f' => 'TSP_SBE_FOOTER_STYLE'));
		$footer_tpl = $theme_dir.$footer_style_cfg;
        if(!is_file($footer_tpl) || !file_exists($footer_tpl)) $footer_tpl = $theme_dir.'footer-style-1.tpl';
		
		$body_class = '';
		if($header_style_cfg) $body_class .= str_replace('.tpl', '', $header_style_cfg) . ' ';

		$smarty->assign(array(
			'THEME_INFO' => $this->name . ' - ' . $this->version,
			'TSP_SBE_STYLE' => $TSP_SBE_STYLE,
			'TSP_SBE_SCRIPT' => $TSP_SBE_SCRIPT,
			'WISHLIST_LINK' => $this->context->link->getModuleLink('blockwishlist', 'mywishlist'),
			'ORDER_PROCESS' => Configuration::get('PS_ORDER_PROCESS_TYPE') ? 'order-opc' : 'order',
			
			'HEADER_STYLE_TPL' => $header_tpl,
			'FOOTER_STYLE_TPL' => $footer_tpl,
			'BODY_CLASS' => $body_class,
			'DEV_MODE' => $this->dev_mode,
		));
		
		// compile scss
		$scssDir = _PS_ALL_THEMES_DIR_._THEME_NAME_.'/sass/';
		$cssDir = _PS_ALL_THEMES_DIR_._THEME_NAME_.'/css/';
		
		$themeColor = strtolower($this->getThemeCfg(array('f' => 'TSP_SBE_THEMECOLOR')));
		//$themeColor2 = strtolower($this->getThemeCfg(array('f' => 'TSP_SBE_THEMECOLOR2')));
		$themeColor2 = '';
		$themeCssName = 'theme-' . str_replace("#", "", $themeColor.$themeColor2) . '.css';
		if(($this->getThemeCfg(array('f' => 'TSP_SBE_SCSSCOMPILE')) == 2 && !file_exists($cssDir . $themeCssName)) || $this->getThemeCfg(array('f' => 'TSP_SBE_SCSSCOMPILE')) == 1) {
			require "scssphp/scss.inc.php";
			require "scssphp/compass/compass.inc.php";
			
			$scss = new scssc();
			new scss_compass($scss);
			
			if($this->getThemeCfg(array('f' => 'TSP_SBE_SCSSFORMAT'))) $cssFormat = $this->getThemeCfg(array('f' => 'TSP_SBE_SCSSFORMAT'));
			else $cssFormat = 'scss_formatter_compressed';
			
			$scss->setFormatter($cssFormat);
			$scss->addImportPath($scssDir);
			
			$variables = '$color1: '.$themeColor.';';
			if($themeColor2 != '') $variables .= '$color2: '.$themeColor2.';';
			$remove_transitions = '@mixin transition($transition...) {}@mixin transition-property($transition-property...) {}@mixin transition-delay($transition-delay) {}@mixin transition-duration($transition-duration...) {}@mixin transition-timing-function($timing-function) {}@mixin transition-transform($transition...) {}';
		
			$string_sass = file_get_contents($scssDir . "var.scss");
			$string_sass .= $variables;
			if($this->getThemeCfg(array('f' => 'TSP_SBE_OFFTRANSITIONS'))) $string_sass .= $remove_transitions;
			
			$string_sass .= file_get_contents($scssDir . "theme.scss");
			
			$string_css = $scss->compile($string_sass);
			$string_css = preg_replace('/\/\*[\s\S]*?\*\//', '', $string_css); // remove mutiple comments
			file_put_contents($cssDir . $themeCssName, $string_css);
		}

		// end compile scss
		$this->callFontIcons();
		$this->context->controller->addCSS(array(
			__PS_BASE_URI__.'themes/'._THEME_NAME_.'/css/'.$themeCssName
		));
		$this->context->controller->removeCSS(array(
			__PS_BASE_URI__.'themes/'._THEME_NAME_.'/css/modules/blockcategories/blockcategories.css',
			__PS_BASE_URI__.'themes/'._THEME_NAME_.'/css/modules/blocklayered/blocklayered.css',
		));
		$jsDefArr = array();
		$jsDefArr['KEEP_MENU'] = (bool)$this->getThemeCfg(array('f' => 'TSP_SBE_STICKYMENU'));
		$jsDefArr['TSP_TOOLTIP'] = (bool)$this->getThemeCfg(array('f' => 'TSP_SBE_SHOWTOOLTIP'));
		Media::addJsDef($jsDefArr);
		
		// theme js
		
		$this->context->controller->addJS(__PS_BASE_URI__.'themes/'._THEME_NAME_.'/js/plg/countdown/jquery.plugin.min.js', 'all');
		$this->context->controller->addJS(__PS_BASE_URI__.'themes/'._THEME_NAME_.'/js/plg/countdown/jquery.countdown.js', 'all');
		
	}
	public function hookAddProduct($params)
	{
		$this->_clearPrdCache('*');
	}
	public function hookUpdateProduct($params)
	{
		$this->_clearPrdCache('*');
	}
	public function hookDeleteProduct($params)
	{
		$this->_clearPrdCache('*');
	}
	public function hookActionOrderStatusPostUpdate($params)
	{
		$this->_clearPrdCache('*');
	}
	public function clearCacheCss () {
		$cssDir = _PS_ALL_THEMES_DIR_._THEME_NAME_.'/css/';
		$cssCacheDir = _PS_ALL_THEMES_DIR_._THEME_NAME_.'/cache/';
	    $this->dellCss($cssDir);
	    $this->dellCss($cssCacheDir, true);
	}
	public function dellCss ($directory, $delall = false) {
		$minute = 60;
	    if ($handle = opendir($directory)) {
	        while (false !== ($file = readdir($handle))) {
	            if ($file != '.' && $file != '..') {
            		if($delall) {
            			if(preg_match("/css$/i", $file) || preg_match("/js$/i", $file)) {
						    $filePath = $directory.$file;
						    $time_elapsed = (time() - filemtime($filePath)) / 60;
							if($time_elapsed > $minute){
								unlink($filePath);
							}
						}
            		} elseif (preg_match("/css$/i", $file) && preg_match("/^theme-/i", $file)) {
					    $filePath = $directory.$file;
					    $time_elapsed = (time() - filemtime($filePath)) / 60;
						if($time_elapsed > $minute){
							unlink($filePath);
						}
					}
	            }
	        }
	        closedir($handle);
	    }
	}
	public function _clearPrdCache($template, $cache_id = NULL, $compile_id = NULL)
	{
		parent::_clearCache('innerleftproduct.tpl');
		parent::_clearCache('displaySecondImage.tpl');
	}
	// smartcode function
	public function getBlockPrdSlider($params) {
		$cache_id = (is_array($params) && count($params)) ? implode('-', $params) : '';
		if (!$this->isCached('tspb-prdslider.tpl', $this->getCacheId($cache_id))) {
			$params['source'] = (int)$params['source'] ? (int)$params['source'] : $params['source'];
			$params['sub_title'] = '';
			if(isset($params['title']) && $params['title']) {
				$titles = explode('|', $params['title']);
				$params['title'] = $titles[0];
				$params['sub_title'] = (isset($titles[1]) && $titles[1]) ? $titles[1] : '';
			}
			$this->smarty->assign($this->getProducts($params, $params['source'], $params['limit']));
			$this->smarty->assign($params);
		}
		return $this->display(__FILE__, 'tspb-prdslider.tpl', $this->getCacheId($cache_id));
	}
	public function getBlockPrdBlock($params) {
		$cache_id = (is_array($params) && count($params)) ? implode('-', $params) : '';
		if (!$this->isCached('tspb-prdblock.tpl', $this->getCacheId($cache_id))) {
			$params['source'] = (int)$params['source'] ? (int)$params['source'] : $params['source'];
			$params['sub_title'] = '';
			if(isset($params['title']) && $params['title']) {
				$titles = explode('|', $params['title']);
				$params['title'] = $titles[0];
				$params['sub_title'] = (isset($titles[1]) && $titles[1]) ? $titles[1] : '';
			}
			$this->smarty->assign($this->getProducts($params, $params['source'], $params['limit']));
			$this->smarty->assign($params);
		}
		return $this->display(__FILE__, 'tspb-prdblock.tpl', $this->getCacheId($cache_id));
	}
	public function getBlockHook($params) {
		$cache_id = (is_array($params) && count($params)) ? implode('-', $params) : '';
		if (!$this->isCached('tspb-hook.tpl', $this->getCacheId($cache_id))) {
			$this->smarty->assign($params);
		}
		return $this->display(__FILE__, 'tspb-hook.tpl', $this->getCacheId($cache_id));
	}
	// end smartcode function
}
global $smarty;

smartyRegisterFunction($smarty, 'function', 'sobie_cfg', 'getSobieCfg');
function getSobieCfg($params, &$smarty) {
	if(!isset($params['f'])) return;
	$theme = new TSPSobieTheme;
	if(isset($params['a']) && $params['a'])
		$smarty->assign($params['a'], $theme->getThemeCfg($params));
	else return $theme->getThemeCfg($params);
}
?>