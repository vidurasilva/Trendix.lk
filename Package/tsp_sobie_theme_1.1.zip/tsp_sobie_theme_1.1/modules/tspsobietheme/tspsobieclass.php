<?php
/**
* 2015 Tpl Solution
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
*  @author    Tpl Solution <contact@tplsolution.com>
*  @copyright 2015 Tpl Solution
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of Tpl Solution
*/

if (!defined('_PS_VERSION_')) exit;

class TSPSobieClass {
	public function getThemeFields ($tab = false) {
		$theme_fields = array();
		$tspp_general = array(
			'TSP_SBE_THEMECOLOR' => '#FB3D3F',
			'TSP_SBE_WRAPPERWIDTH' => '1440',
			'TSP_SBE_FONT1' => 'GF:Roboto:100,100italic,300,300italic,regular,italic,500,500italic,700,700italic,900,900italic:greek,vietnamese,cyrillic,latin,latin-ext,cyrillic-ext,greek-ext',
			'TSP_SBE_FONTSIZE' => '13px',
			'TSP_SBE_BODYCOLOR' => '#f7f7f7',
			'TSP_SBE_BODYIMG' => 'pattern_10.png',
			'TSP_SBE_FONT2' => '0',
			'TSP_SBE_FONT2TARGETS' => '',
			'TSP_SBE_FONT3' => '0',
			'TSP_SBE_FONT3TARGETS' => '',
			'TSP_SBE_SECONDIMG' => '1',
			'TSP_SBE_ADDTHISBTN' => '0',
			'TSP_SBE_ICOCART' => 'fa fa-shopping-cart',
			'TSP_SBE_ICOQUICKVIEW' => 'fa fa-eye',
			'TSP_SBE_ICOCOMPARE' => 'fa fa-exchange',
			'TSP_SBE_ICOWISHLIST' => 'fa fa-heart-o',
			'TSP_SBE_BUSINESSHOUR' => '1',
			'TSP_SBE_CONTACTUS' => '1',
		);
		$tspp_header = array(
			'TSP_SBE_WELCOMEMESS' => array(
				'default' => 'Wellcome to Sobie stores !',
				'lang' => 'true',
			),
			'TSP_SBE_CUSTOMLOGO' => '1',
			'TSP_SBE_CUSTOMLOGO_URL' => array(
				'default' => '__TSPPS_BASE_URI__themes/tsp_sobie/images/logo.png',
				'lang' => 'true',
			),
			'TSP_SBE_HEADER_STYLE' => 'header-style-1.tpl',
			'TSP_SBE_STICKYMENU' => '0',
			'TSP_SBE_FOOTER_STYLE' => 'footer-style-1.tpl',
			'TSP_SBE_FOOTER_LOGO' => array(
				'default' => '__TSPPS_BASE_URI__themes/tsp_sobie/images/logo-f.png',
				'lang' => 'true',
			),
			'TSP_SBE_FOOTERLINKS' => array(
				'default' => 'our_stores,price_drop,new_products,best_sales,contact_us,sitemap',
				'type' => 'multiple_select',
			),
			'TSP_SBE_FOOTER' => array(
				'default' => '<div class="row"><div class="col-md-3 col-xs-6 col-phone-12">[tspb_hook h="displayContactUs"][/tspb_hook]</div><div class="col-md-3 col-xs-6 col-phone-12">[tspb_hook h="displayBusinessHours"][/tspb_hook]</div><div class="clearfix visible-xs"></div><div class="col-md-3 col-xs-6 col-phone-12">[tspb_hook h="displayTwitter"][/tspb_hook]</div><div class="col-md-3 col-xs-6 col-phone-12">[tspb_hook h="displayFooter"][/tspb_hook]</div></div>',
				'lang' => 'true',
			),
			'TSP_SBE_COPYRIGHT' => array(
				'default' => '&copy; 2016 Ecommerce software by <a target="_blank" class="_blank" href="http://www.prestashop.com">PrestaShop&trade; </a>.',
				'lang' => 'true',
			),
			'TSP_SBE_PAYMENTLOGO' => array(
				'default' => '__TSPPS_BASE_URI__themes/tsp_sobie/images/payment-logo.png',
				'lang' => 'true',
			),
		);
		$tspp_homepage = array(
			'TSP_SBE_HOMEPAGE_TSPB' => array(
				'default' => '<div data-backend="" class="tspb-section row" style="position: relative;"><div data-backend=""><div data-backend="" class="section_in"><div data-backend="" data-after="section-control" class="scode-options">[tspb_section class="parallax-scroll" container="0" bg_image="" bg_color="#f2f2f2" bg_type="fullwidth" bg_repeat="no-repeat" bg_attachment="scroll" bg_position="center center" bg_size="auto" pt="" pr="" pb="" pl="" mt="" mr="" mb="70" ml=""][/tspb_section]</div><div data-backend="" class="tspb-column col-xs-12"><div data-backend="" data-after="column-control" class="scode-options">[tspb_column sm="12"][/tspb_column]</div><div class="tspb-column-in ui-sortable"><div class="tspb-widget tspb-widget-hook"><div data-after="widget-control" class="scode-options" data-code="tspb_hook" data-text="Hook">[tspb_hook h="displaySlideshow" custom_h=""][/tspb_hook]</div></div></div></div></div></div></div><div data-backend="" class="tspb-section row" style="position: relative;"><div data-backend=""><div data-backend="" class="section_in"><div data-backend="" data-after="section-control" class="scode-options">[tspb_section class="grid-nopadding parallax-scroll hidden" container="0" bg_image="" bg_color="" bg_type="fullwidth" bg_repeat="no-repeat" bg_attachment="scroll" bg_position="center center" bg_size="auto" pt="" pr="" pb="" pl="" mt="" mr="" mb="70" ml=""][/tspb_section]</div><div data-backend="" class="tspb-column col-xs-4"><div data-backend="" data-after="column-control" class="scode-options">[tspb_column sm="4"][/tspb_column]</div><div class="tspb-column-in ui-sortable"><div class="tspb-widget tspb-widget-banner"><div data-after="widget-control" class="scode-options" data-code="tspb_banner" data-text="Banner Block">[tspb_banner title="" class="" style="banner-3" link="#" src="__TSPPS_BASE_URI__themes/tsp_sobie/images/bn1.jpg"][/tspb_banner]</div></div></div></div><div data-backend="" class="tspb-column col-xs-4"><div data-backend="" data-after="column-control" class="scode-options">[tspb_column sm="4"][/tspb_column]</div><div class="tspb-column-in ui-sortable"><div class="tspb-widget tspb-widget-banner"><div data-after="widget-control" class="scode-options" data-code="tspb_banner" data-text="Banner Block">[tspb_banner title="" class="" style="banner-3" link="" src="__TSPPS_BASE_URI__themes/tsp_sobie/images/bn2.jpg"][/tspb_banner]</div></div></div></div><div data-backend="" class="tspb-column col-xs-4"><div data-backend="" data-after="column-control" class="scode-options">[tspb_column sm="4"][/tspb_column]</div><div class="tspb-column-in ui-sortable"><div class="tspb-widget tspb-widget-banner"><div data-after="widget-control" class="scode-options" data-code="tspb_banner" data-text="Banner Block">[tspb_banner title="" class="" style="banner-3" link="" src="__TSPPS_BASE_URI__themes/tsp_sobie/images/bn3.jpg"][/tspb_banner]</div></div></div></div></div></div></div><div data-backend="" class="tspb-section row" style="position: relative;"><div data-backend=""><div data-backend="" class="section_in"><div data-backend="" data-after="section-control" class="scode-options">[tspb_section class="" container="1" bg_image="" bg_color="" bg_type="fullwidth" bg_repeat="no-repeat" bg_attachment="scroll" bg_position="center center" bg_size="auto" pt="" pr="" pb="" pl="" mt="" mr="" mb="70" ml=""][/tspb_section]</div><div data-backend="" class="tspb-column col-xs-12"><div data-backend="" data-after="column-control" class="scode-options">[tspb_column sm="12"][/tspb_column]</div><div class="tspb-column-in ui-sortable"><div class="tspb-widget tspb-widget-hook"><div data-after="widget-control" class="scode-options" data-code="tspb_hook" data-text="Hook">[tspb_hook h="displayTSPProductTabs" custom_h=""][/tspb_hook]</div></div></div></div></div></div></div><div data-backend="" class="tspb-section row" style="position: relative;"><div data-backend=""><div data-backend="" class="section_in"><div data-backend="" data-after="section-control" class="scode-options">[tspb_section class="" container="1" bg_image="" bg_color="#f7f7f7" bg_type="fullwidth" bg_repeat="repeat" bg_attachment="scroll" bg_position="center center" bg_size="cover" pt="70" pr="" pb="70" pl="" mt="" mr="" mb="70" ml=""][/tspb_section]</div><div data-backend="" class="tspb-column col-xs-12"><div data-backend="" data-after="column-control" class="scode-options">[tspb_column sm="12"][/tspb_column]</div><div class="tspb-column-in ui-sortable"><div class="tspb-widget tspb-widget-hook"><div data-after="widget-control" class="scode-options" data-code="tspb_hook" data-text="Hook">[tspb_hook h="displayDealsProducts" custom_h=""][/tspb_hook]</div></div></div></div></div></div></div><div data-backend="" class="tspb-section row" style="position: relative;"><div data-backend=""><div data-backend="" class="section_in"><div data-backend="" data-after="section-control" class="scode-options">[tspb_section class="shop-policy hidden" container="1" bg_image="" bg_color="#f2f2f2" bg_type="fullwidth" bg_repeat="no-repeat" bg_attachment="scroll" bg_position="center center" bg_size="auto" pt="50" pr="" pb="50" pl="" mt="" mr="" mb="70" ml=""][/tspb_section]</div><div data-backend="" class="tspb-column col-xs-12"><div data-backend="" data-after="column-control" class="scode-options">[tspb_column class="" sm="12" xs="0" xs_hide="0" sm_hide="0" md="4" md_hide="0" lg="0" lg_hide="0"][/tspb_column]</div><div class="tspb-column-in ui-sortable"><div class="tspb-widget tspb-widget-textblock" style="position: relative;"><div data-after="widget-control" class="scode-options" data-code="tspb_textblock" data-text="Text Block">[tspb_textblock class=service-box]&lt;a title="Free Shipping Item" href="#" class="fa fa-truck icon"&gt;&lt;/a&gt;&lt;h5&gt;&lt;a title="Free Shipping Item" href="#"&gt;Free Shipping Item&lt;/a&gt;&lt;/h5&gt;&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque rhoncus sapien sed felis laoreet.&lt;/p&gt;[/tspb_textblock]</div></div></div></div><div data-backend="" class="tspb-column col-xs-12"><div data-backend="" data-after="column-control" class="scode-options">[tspb_column class="" sm="12" xs="0" xs_hide="0" sm_hide="0" md="4" md_hide="0" lg="0" lg_hide="0"][/tspb_column]</div><div class="tspb-column-in ui-sortable"><div class="tspb-widget tspb-widget-textblock"><div data-after="widget-control" class="scode-options" data-code="tspb_textblock" data-text="Text Block">[tspb_textblock class=service-box]&lt;a title="Accepting orders 24/7" href="#" class="fa fa-suitcase icon"&gt;&lt;/a&gt;&lt;h5&gt;&lt;a title="Accepting orders 24/7" href="#"&gt;Accepting orders 24/7&lt;/a&gt;&lt;/h5&gt;&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque rhoncus sapien sed felis laoreet.&lt;/p&gt;[/tspb_textblock]</div></div></div></div><div data-backend="" class="tspb-column col-xs-12"><div data-backend="" data-after="column-control" class="scode-options">[tspb_column class="" sm="12" xs="0" xs_hide="0" sm_hide="0" md="4" md_hide="0" lg="0" lg_hide="0"][/tspb_column]</div><div class="tspb-column-in ui-sortable"><div class="tspb-widget tspb-widget-textblock"><div data-after="widget-control" class="scode-options" data-code="tspb_textblock" data-text="Text Block">[tspb_textblock class=service-box]&lt;a title="30 day return policy" href="#" class="fa fa-paper-plane"&gt;&lt;/a&gt;&lt;h5&gt;&lt;a title="30 day return policy" href="#"&gt;30 day return policy&lt;/a&gt;&lt;/h5&gt;&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque rhoncus sapien sed felis laoreet.&lt;/p&gt;[/tspb_textblock]</div></div></div></div></div></div></div><div data-backend="" class="tspb-section row" style="position: relative;"><div data-backend=""><div data-backend="" class="section_in"><div data-backend="" data-after="section-control" class="scode-options">[tspb_section class="" container="1" bg_image="" bg_color="" bg_type="fullwidth" bg_repeat="no-repeat" bg_attachment="scroll" bg_position="center center" bg_size="auto" pt="" pr="" pb="" pl="" mt="" mr="" mb="70" ml=""][/tspb_section]</div><div data-backend="" class="tspb-column col-xs-12"><div data-backend="" data-after="column-control" class="scode-options">[tspb_column sm="12"][/tspb_column]</div><div class="tspb-column-in ui-sortable"><div class="tspb-widget tspb-widget-hook"><div data-after="widget-control" class="scode-options" data-code="tspb_hook" data-text="Hook">[tspb_hook h="displayTSPProductTabsSlider" custom_h=""][/tspb_hook]</div></div></div></div></div></div></div><div data-backend="" class="tspb-section row" style="position: relative;"><div data-backend=""><div data-backend="" class="section_in"><div data-backend="" data-after="section-control" class="scode-options">[tspb_section class="" container="1" bg_image="" bg_color="" bg_type="fullwidth" bg_repeat="no-repeat" bg_attachment="scroll" bg_position="center center" bg_size="auto" pt="" pr="" pb="" pl="" mt="" mr="" mb="70" ml=""][/tspb_section]</div><div data-backend="" class="tspb-column col-xs-12"><div data-backend="" data-after="column-control" class="scode-options">[tspb_column sm="12"][/tspb_column]</div><div class="tspb-column-in ui-sortable"><div class="tspb-widget tspb-widget-hook"><div data-after="widget-control" class="scode-options" data-code="tspb_hook" data-text="Hook">[tspb_hook h="displayTestimonials" custom_h=""][/tspb_hook]</div></div></div></div></div></div></div><div data-backend="" class="tspb-section row"><div data-backend=""><div data-backend="" class="section_in"><div data-backend="" data-after="section-control" class="scode-options">[tspb_section class="" container="1" bg_image="" bg_color="" bg_type="fullwidth" bg_repeat="no-repeat" bg_attachment="scroll" bg_position="center center" bg_size="auto" pt="" pr="" pb="" pl="" mt="" mr="" mb="70" ml=""][/tspb_section]</div><div data-backend="" class="tspb-column col-xs-12"><div data-backend="" data-after="column-control" class="scode-options">[tspb_column class="" sm="12" xs="0" xs_hide="0" sm_hide="0" md="7" md_hide="0" lg="8" lg_hide="0"][/tspb_column]</div><div class="tspb-column-in ui-sortable"><div class="tspb-widget tspb-widget-hook"><div data-after="widget-control" class="scode-options" data-code="tspb_hook" data-text="Hook">[tspb_hook h="displayLatestblog" custom_h=""][/tspb_hook]</div></div></div></div><div data-backend="" class="tspb-column col-xs-12"><div data-backend="" data-after="column-control" class="scode-options">[tspb_column class="" sm="12" xs="0" xs_hide="0" sm_hide="0" md="5" md_hide="0" lg="4" lg_hide="0"][/tspb_column]</div><div class="tspb-column-in ui-sortable"><div class="tspb-widget tspb-widget-emptyspace" style="position: relative;"><div data-after="widget-control" class="scode-options" data-code="tspb_emptyspace" data-text="Empty Space" id="">[tspb_emptyspace height="70" class="hidden-md hidden-lg clearfix"][/tspb_emptyspace]</div></div><div class="tspb-widget tspb-widget-hook"><div data-after="widget-control" class="scode-options" data-code="tspb_hook" data-text="Hook">[tspb_hook h="displayOurbrands" custom_h=""][/tspb_hook]</div></div></div></div></div></div></div>',
				'lang' => 'true',
			),
		);
		$tspp_slideshow = array(
			'TSP_SBE_SLSTATUS' => '1',
			'TSP_SBE_SLWIDTH' => '1100',
			'TSP_SBE_SLHEIGHT' => '650',
			'TSP_SBE_SLAUTO' => '7000',
			'TSP_SBE_SLANIMATEIN' => 'fadeIn',
			'TSP_SBE_ANIMATEOUT' => 'fadeOut',
			'TSP_SBE_SLIMGS' => array(
				'default' => 'a:2:{s:31:"_144360798798009247773254755884";a:3:{s:5:"title";s:12:"TPL Solution";s:4:"link";s:1:"#";s:3:"img";s:49:"__TSPPS_BASE_URI__themes/tsp_sobie/images/sl1.jpg";}s:31:"_144360803306404532126223202795";a:3:{s:5:"title";s:12:"TPL Solution";s:4:"link";s:1:"#";s:3:"img";s:49:"__TSPPS_BASE_URI__themes/tsp_sobie/images/sl2.jpg";}}',
				'lang' => 'true',
				'type' => 'additem',
			),
		);
		$tspp_testimonial = array(
			'TSP_SBE_TESTIMONIAL_STATUS' => '1',
			'TSP_SBE_TESTIMONIAL_TITLE' => array(
				'default' => 'What people say ?|Quotes & Testimonials',
				'lang' => 'true',
			),
			'TSP_SBE_TESTIMONIAL_DESC' => array(
				'default' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat',
				'lang' => 'true',
			),
			'TSP_SBE_TESTIMONIALS' => array(
				'default' => 'a:5:{s:31:"_144373180560206088342105504125";a:4:{s:5:"title";s:14:"Amazing design";s:4:"name";s:19:"John Doe - Designer";s:6:"avatar";s:54:"__TSPPS_BASE_URI__themes/tsp_sobie/images/avatar/1.jpg";s:4:"desc";s:191:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper.";}s:29:"_1443731806321094069904088974";a:4:{s:5:"title";s:21:"Clean and easy to use";s:4:"name";s:20:"John Doe - Developer";s:6:"avatar";s:54:"__TSPPS_BASE_URI__themes/tsp_sobie/images/avatar/2.jpg";s:4:"desc";s:191:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper.";}s:31:"_144373180716001395485596731305";a:4:{s:5:"title";s:17:"Easy to work with";s:4:"name";s:22:"John Doe - Founder TPL";s:6:"avatar";s:54:"__TSPPS_BASE_URI__themes/tsp_sobie/images/avatar/3.jpg";s:4:"desc";s:191:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper.";}s:31:"_145831540085805918736737221479";a:4:{s:5:"title";s:21:"Clean and easy to use";s:4:"name";s:20:"John Doe - Developer";s:6:"avatar";s:54:"__TSPPS_BASE_URI__themes/tsp_sobie/images/avatar/4.jpg";s:4:"desc";s:191:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper.";}s:31:"_145831540145809746381887234747";a:4:{s:5:"title";s:17:"Easy to work with";s:4:"name";s:22:"John Doe - Founder TPL";s:6:"avatar";s:54:"__TSPPS_BASE_URI__themes/tsp_sobie/images/avatar/5.jpg";s:4:"desc";s:191:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper.";}}',
				'lang' => 'true',
				'type' => 'additem',
			),
		);
		$tspp_social = array(
			'TSP_SBE_SOCIAL_STATUS' => '1',
			'TSP_SBE_SOCIAL_TITLE' => array(
				'default' => 'Follow Us',
				'lang' => 'true',
			),
			'TSP_SBE_SOCIAL' => array(
				'default' => 'a:5:{s:31:"_143658541269107175693494331554";a:4:{s:5:"title";s:12:"Tpl Solution";s:4:"link";s:1:"#";s:4:"icon";s:23:"fa fa-facebook-official";s:6:"target";s:5:"_self";}s:31:"_143658543388907976694577514183";a:4:{s:5:"title";s:12:"Tpl Solution";s:4:"link";s:1:"#";s:4:"icon";s:13:"fa fa-twitter";s:6:"target";s:5:"_self";}s:32:"_1436585443416037046733068181104";a:4:{s:5:"title";s:12:"Tpl Solution";s:4:"link";s:1:"#";s:4:"icon";s:17:"fa fa-google-plus";s:6:"target";s:5:"_self";}s:32:"_1436585458765014645261988344394";a:4:{s:5:"title";s:12:"Tpl Solution";s:4:"link";s:1:"#";s:4:"icon";s:15:"fa fa-instagram";s:6:"target";s:5:"_self";}s:31:"_144597003732306060635705678492";a:4:{s:5:"title";s:12:"Tpl Solution";s:4:"link";s:1:"#";s:4:"icon";s:13:"fa fa-youtube";s:6:"target";s:5:"_self";}}',
				'lang' => 'true',
				'type' => 'additem',
			),
		);
		$tspp_ourbrand = array(
			'TSP_SBE_OURBRAND_STATUS' => '1',
			'TSP_SBE_OURBRAND_TITLE' => array(
				'default' => 'Our Partners|Partners',
				'lang' => 'true',
			),
			'TSP_SBE_OURBRAND_DESC' => array(
				'default' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat',
				'lang' => 'true',
			),
			'TSP_SBE_OURBRANDS' => array(
				'default' => 'a:9:{s:32:"_1443731948575045758539042435586";a:4:{s:5:"title";s:12:"TPL Solution";s:4:"link";s:1:"#";s:6:"target";s:5:"_self";s:4:"logo";s:54:"__TSPPS_BASE_URI__themes/tsp_sobie/images/brands/1.png";}s:31:"_144373196111705864742984995246";a:4:{s:5:"title";s:12:"TPL Solution";s:4:"link";s:1:"#";s:6:"target";s:5:"_self";s:4:"logo";s:54:"__TSPPS_BASE_URI__themes/tsp_sobie/images/brands/2.png";}s:31:"_144373196156404697384387254715";a:4:{s:5:"title";s:12:"TPL Solution";s:4:"link";s:1:"#";s:6:"target";s:5:"_self";s:4:"logo";s:54:"__TSPPS_BASE_URI__themes/tsp_sobie/images/brands/3.png";}s:32:"_1443731962054029904843121767044";a:4:{s:5:"title";s:12:"TPL Solution";s:4:"link";s:1:"#";s:6:"target";s:5:"_self";s:4:"logo";s:54:"__TSPPS_BASE_URI__themes/tsp_sobie/images/brands/4.png";}s:31:"_144373196298504146616749931127";a:4:{s:5:"title";s:12:"TPL Solution";s:4:"link";s:1:"#";s:6:"target";s:5:"_self";s:4:"logo";s:54:"__TSPPS_BASE_URI__themes/tsp_sobie/images/brands/5.png";}s:31:"_144599750943808190314952665013";a:4:{s:5:"title";s:12:"TPL Solution";s:4:"link";s:1:"#";s:6:"target";s:5:"_self";s:4:"logo";s:54:"__TSPPS_BASE_URI__themes/tsp_sobie/images/brands/6.png";}s:31:"_145806592074107843714684713632";a:4:{s:5:"title";s:12:"TPL Solution";s:4:"link";s:1:"#";s:6:"target";s:5:"_self";s:4:"logo";s:54:"__TSPPS_BASE_URI__themes/tsp_sobie/images/brands/2.png";}s:32:"_1458065921362036852953862398863";a:4:{s:5:"title";s:12:"TPL Solution";s:4:"link";s:1:"#";s:6:"target";s:5:"_self";s:4:"logo";s:54:"__TSPPS_BASE_URI__themes/tsp_sobie/images/brands/3.png";}s:31:"_145806592208008382267609704286";a:4:{s:5:"title";s:12:"TPL Solution";s:4:"link";s:1:"#";s:6:"target";s:5:"_self";s:4:"logo";s:54:"__TSPPS_BASE_URI__themes/tsp_sobie/images/brands/4.png";}}',
				'lang' => 'true',
				'type' => 'additem',
			),
		);
		$tspp_events = array(
			'TSP_SBE_EVENTS_STATUS' => '1',
			'TSP_SBE_EVENTS_TITLE' => array(
				'default' => 'Events',
				'lang' => 'true',
			),
			'TSP_SBE_EVENTS_DESC' => array(
				'default' => '',
				'lang' => 'true',
			),
			'TSP_SBE_EVENTS' => array(
				'default' => 'a:2:{s:31:"_145622288698303770171769428998";a:2:{s:4:"desc";s:208:"Save <strong class="highlight">25% OFF</strong> Shirt, Fashion Tops & Sweaters. Free shipping on select orders over $49. The offer is available for a week only! <strong class="highlight">View Now >></strong> ";s:4:"link";s:1:"#";}s:31:"_145622292001705775558457244188";a:2:{s:4:"desc";s:160:"Save <strong class="highlight">20% OFF</strong> Jeans, Fashion Tops & Sweaters. Free shipping on select orders over $25. The offer is available for a week only!";s:4:"link";s:1:"#";}}',
				'lang' => 'true',
				'type' => 'additem',
			),
		);
		$tspp_advance = array(
			'TSP_SBE_SCSSCOMPILE' => '2',
			'TSP_SBE_SCSSFORMAT' => 'scss_formatter_compressed',
			'TSP_SBE_OFFTRANSITIONS' => '0',
			'TSP_SBE_SHOWCPANEL' => '0',
			'TSP_SBE_SHOWTOOLTIP' => '0',
		);
		$tspp_customcssjs = array(
			'TSP_SBE_CUSTOMCSS' => '',
			'TSP_SBE_CUSTOMJS' => '',
		);
		$theme_fields = array_merge($theme_fields, $this->addFieldProperties($tspp_general));
		$theme_fields = array_merge($theme_fields, $this->addFieldProperties($tspp_header));
		$theme_fields = array_merge($theme_fields, $this->addFieldProperties($tspp_slideshow));
		$theme_fields = array_merge($theme_fields, $this->addFieldProperties($tspp_homepage));
		$theme_fields = array_merge($theme_fields, $this->addFieldProperties($tspp_testimonial));
		$theme_fields = array_merge($theme_fields, $this->addFieldProperties($tspp_social));
		$theme_fields = array_merge($theme_fields, $this->addFieldProperties($tspp_ourbrand));
		$theme_fields = array_merge($theme_fields, $this->addFieldProperties($tspp_events));
		$theme_fields = array_merge($theme_fields, $this->addFieldProperties($tspp_advance));
		$theme_fields = array_merge($theme_fields, $this->addFieldProperties($tspp_customcssjs));

		if($tab) {
			return $this->addFieldProperties($$tab);
		} else {
			return $theme_fields;
		}
	}
	public function addFieldProperties($fields) {
		foreach($fields as &$field) {
			!is_array($field) && settype($field, 'array');
			if(isset($field[0])) {
				$field['default'] = $field[0];
				unset($field[0]);
			}
			$field['type'] = (isset($field['type'])) ? $field['type'] : false;
			$field['lang'] = (isset($field['lang'])) ? $field['lang'] : false;
		}
		return $fields;
	}
	public function delField() {
//		Configuration::deleteByName('TSP_SBE_');

//		$curr = array();
//		$using = array();
//		$sql = 'SELECT name FROM '._DB_PREFIX_.'configuration WHERE name like "TSP_SBE_%"';
//		$results = Db::getInstance()->ExecuteS($sql);
//		$fields = $this->TSPClass->getThemeFields();
//		foreach($results as $field) $curr[] = $field['name'];
//		foreach($fields as $field => $info) $using[] = $field;
//		$diff = array_diff($curr,$using);
//		foreach($diff as $field) Configuration::deleteByName($field);
	}
	public function getBaseUrl(){
		if (!empty($_SERVER['HTTPS']) && ('on' == $_SERVER['HTTPS']))
			return 'https://'.Tools::getShopDomain();
		else
			return 'http://'.Tools::getShopDomain();
	}
	public function replaceLinkContent($string, $out = false) {
		if($out) {
			return str_replace('__TSPPS_BASE_URI__', $this->getBaseUrl().__PS_BASE_URI__, $string);
		} else { 
			$return = str_replace(_PS_BASE_URL_SSL_.__PS_BASE_URI__, '__TSPPS_BASE_URI__', $string); 
			return str_replace(_PS_BASE_URL_.__PS_BASE_URI__, '__TSPPS_BASE_URI__', $return); 
		}
	}
}
?>