jQuery(document).ready(function(){
	if($('#tspp-tabs').length) {
		$('#tspp-tabs').show();
		if($.cookie('tspp_tab_active') != undefined && $('[id^="'+$.cookie('tspp_tab_active')+'"]').length)
			var tab = $('#tspp-tabs .tab[data-tab="'+$.cookie('tspp_tab_active')+'"]');
		else 
			var tab = $('#tspp-tabs .tab:first');
		
		var tabId = tab.attr('data-tab');
		tab.addClass('active');
		$('[id^="'+tabId+'"]').addClass('active');
		
		
		$('#tspp-tabs').find('.tab').on('click', function() {
			hidetabs();
			$(this).addClass('active');
			$.cookie('tspp_tab_active', $(this).attr('data-tab'));
			var tabId = $(this).data('tab');
			$('[id^="'+tabId+'"]').addClass('active');
		});
	}
	$('.list-item').sortable({
		handle: '.handle'
	});
	$(document).on('click', '.remove-additem', function(){
		$(this).parents('.additem-row').remove();
	});
});
function hidetabs() {
	$('#tspp-tabs').find('.tab').each(function(index){
		var tabId = $(this).data('tab');
		$(this).removeClass('active');
		$('[id^="'+tabId+'"]').removeClass('active');
	});
}

// img field
$(document).on('click', '.tsp-imgfield-open', function(e){
	e.preventDefault();
    var adminpath = window.location.pathname;
    adminpath = adminpath.substring(0,adminpath.lastIndexOf('/') + 1);
    
    var filemanagerurl = adminpath+'filemanager/dialog.php';
    var win = window.self;
    var id = $(this).attr('data-field_id');
    tinymce.activeEditor.windowManager.open({
         title: 'Image Manager',
         file: filemanagerurl+'?type=1',
         width: 860,  
         height: 570,
         resizable: true,
         maximizable: true,
         inline: 1
         }, {
         setUrl: function (url) {
             var fieldElm = win.document.getElementById(id);                     
             fieldElm.value = url;
         }
     });
});
$(document).on('click', '.tsp-imgfield-remove', function(){
	var _btn = $(this);
	var _wrap = _btn.parents('.tsp-imgfield');
	var _input = _wrap.find('.tsp-imgfield-input');
	_input.val('');
});
$(document).on('click', '.img-preview', function(e){
	var _this = $(this);
	var href = $('#'+_this.attr('data-field_id')).val();
	
	$("<img>", {
	    src: href,
	    error: function() {
			e.preventDefault();
			alert('Image does not exist !!');
	    },
	    load: function() {
			$.fancybox({
				'href' : href
			});
	    }
	});
});
// end img field





var _tspb = {
    init: function() {
        var that = this;
        that.setSortable();
        that.addControls();
    },
    getOptions: function (el, tag, onlyContent) {
    	var _optionsStr = el.html();
        matches = _optionsStr.match(this.regexp(tag));
        if(typeof(onlyContent)!='undefined') return matches[5];
        return this.attrs(matches[3]);
    },
	regexp: function( tag ) {
		return new RegExp('\\[(\\[?)(' + tag + ')(?![\\w-])([^\\]\\/]*(?:\\/(?!\\])[^\\]\\/]*)*?)(?:(\\/)\\]|\\](?:([^\\[]*(?:\\[(?!\\/\\2\\])[^\\[]*)*)(\\[\\/\\2\\]))?)(\\]?)');
	},
	attrs: function( text ) {
		var named   = {}, pattern, match;
		pattern = /(\w+)\s*=\s*"([^"]*)"(?:\s|$)|(\w+)\s*=\s*\'([^\']*)\'(?:\s|$)|(\w+)\s*=\s*([^\s\'"]+)(?:\s|$)|"([^"]*)"(?:\s|$)|(\S+)(?:\s|$)/g;
		// Map zero-width spaces to actual spaces.
		text = text.replace( /[\u00a0\u200b]/g, ' ' );
		// Match and normalize attributes.
		while ( (match = pattern.exec( text )) ) {
			if ( match[1] ) named[ match[1].toLowerCase() ] = match[2];
			else if ( match[3] ) named[ match[3].toLowerCase() ] = match[4];
			else if ( match[5] ) named[ match[5].toLowerCase() ] = match[6];
		}
		return named;
	},
	addControls: function () {
		var _secControl = $('.tspb-templates > .tspb-section-controls-tpl').html();
		$('[data-after="section-control"]').each(function(){
			if($(this).find('~ .controls_section').length == 0) $(this).after(_secControl);
		});
		var _colControl = $('.tspb-templates > .tspb-column-controls-tpl').html();
		$('[data-after="column-control"]').each(function(){
			if($(this).find('~ .controls_col').length == 0) $(this).after(_colControl);
		});
		var _rowControl = $('.tspb-templates > .tspb-row-controls-tpl').html();
		$('[data-after="row-control"]').each(function(){
			if($(this).find('~ .controls_row').length == 0) $(this).after(_rowControl);
		});
		
		
		$('[data-after="widget-control"]').each(function(){
			if($(this).find('~ .controls_widget').length == 0) {
				var _title = $(this).attr('data-text');
				var _scode = $(this).attr('data-code');
				var _widgetControl = '<!-- backend --><div class="tspb-controls controls_widget"><div class="ico-action handle"><i class="icon-arrows"></i></div><div class="ico-action action-edit edit-' + _scode + '"><i class="icon-cog"></i></div><div class="ico-action action-delete"><i class="icon-trash"></i></div></div><h4>' + _title + '</h4><!-- /backend -->';
				$(this).after(_widgetControl);
			}
		});
			
//		var widgets = [ 'hook', 'textblock'];
//		$.each(widgets, function( index, code ) {
//			var _control = $('.tspb-templates > .tspb-widget-' + code + '-controls-tpl').html();
//			$('[data-after="widget-' + code + '-control"]').each(function(){
//				$(this).show();
//				if($(this).find('~ .controls_widget').length == 0) $(this).after(_control);
//			});
//		});
	},
	setSortable: function () {
		$('.tspb-content').sortable({
			handle: '.controls_section .handle'
		});
		$('.tspb-column > .tspb-column-in').sortable({
			handle: '> .tspb-controls .handle'
		});
	},
	updateHtmlForm: function (el) {
		el.find('input').each(function(){
			$(this).attr('value', $(this).val());
		});
		el.find('select').each(function(){
			$(this).attr('value', $(this).val());
			$(this).find('option:selected').attr('selected', 'selected');
		});
	},
	getFormOptions: function (el) {
		var _options = '';
		el.find('input').each(function(){
			var name = $(this).attr('name');
			var value = $(this).attr('value');
			_options += ' ' + name + '="' + value + '"';
		});
		el.find('select').each(function(){
			var name = $(this).attr('name');
			var value = $(this).find('option:selected').val();
			_options += ' ' + name + '="' + value + '"';
		});
		return _options;
	},
	addSection: function (el) {
		var tpl = '<div data-backend class="tspb-section row"><div data-backend><div data-backend class="section_in">';
		tpl += '<div data-backend data-after="section-control" class="scode-options">[tspb_section][/tspb_section]</div>';
		tpl += '</div></div></div>';
		el.append(tpl);
	    _tspb.addControls();
	},
	addColumns: function (el, width) {
		var tpl = '<div data-backend class="tspb-column col-xs-' + width + '"><div data-backend data-after="column-control" class="scode-options">[tspb_column sm="' + width + '"][/tspb_column]</div><div class="tspb-column-in"></div></div>';
		el.append(tpl);
	    _tspb.addControls();
	},
	addRow: function (el) {
		var tpl = '<div class="tspb-row row"><div data-after="row-control" class="scode-options"></div></div>';
		el.append(tpl);
	    _tspb.addControls();
	},
	addWidget: function (el, code, title) {
		if(code == 'row') return _tspb.addRow(el);
		var tpl = '<div class="tspb-widget tspb-widget-' + code + '"><div data-after="widget-control" class="scode-options" data-code="tspb_' + code + '" data-text="' + title + '">[tspb_' + code + '][/tspb_' + code + ']</div></div>';
		el.append(tpl);
	    _tspb.addControls();
	},
	encodeEntities: function (s){
		return $("<div/>").text(s).html();
	},
	dencodeEntities: function (s){
		return $("<div/>").html(s).text();
	}
};

jQuery(document).ready(function(){
	_tspb.init();
});
// section
$(document).on('click', '.tspb-add-section', function(e){
	e.preventDefault();
    _tspb.addSection($(this).parents('.tspb-container').find('.tspb-content'));
});
// section action btn
$(document).on('click', '.controls_section .ico-action', function(e){
	e.preventDefault();
	var _section = $(this).parents('.tspb-section');
	var _control = $(this).parents('.tspb-controls');
	if($(this).hasClass('action-delete')) _section.remove();
	if($(this).hasClass('action-clone')) _section.after(_section.clone());
	
	if($(this).hasClass('action-addcolumn')) {
		_tspb.addColumns(_section.find('.section_in'), 12);
	}
	if($(this).hasClass('action-edit')) {
		var _optionsTag = $(this).parents('.tspb-controls').parent().find('> .scode-options');
		_optionsTag.attr('id', 'tspb_current_edit');
		_options = _tspb.getOptions(_optionsTag, 'tspb_section');
		var _sectionOptionsTpl = $('.tspb-templates > .tspb-section-options-tpl').html();
		$('#tspb_options_wrapper').html(_sectionOptionsTpl);

		$.each(_options, function( k, v ) {
		//	console.log(k, v);
			var form_ctr = $('#tspb_options_wrapper').find('[name="' + k + '"]');
			if(form_ctr.prop('tagName') == 'INPUT') form_ctr.val(v);
			if(form_ctr.prop('tagName') == 'SELECT') form_ctr.find('[value="' + v + '"]').attr('selected', 'selected');
			if(form_ctr.prop('tagName') == 'TEXTAREA') form_ctr.html(v);
		});
		$('#tspb_options_wrapper').find('.tsp-imgfield').each(function(){
		    var date = new Date();
		    var now = date.getTime();
			var _eq = '_' + now + Math.random().toString().replace('.', '');
			$(this).find('.tsp-imgfield-input').attr('id', 'tspb_img' + _eq);
			$(this).find('.tsp-imgfield-open').attr('data-field_id', 'tspb_img' + _eq);
		});
		$.fancybox({
			'href' : '#tspb_options_wrapper',
			maxWidth	: 800,
			minWidth	: 500,
			width		: '70%',
			helpers: { overlay: { locked: false } },
			beforeClose	: function () {
				_optionsTag.attr('id', '');
			}
		});
	}
});
$(document).on('submit','.tspb-options-form',function(e){
	e.preventDefault();
	var data = $(this).serializeArray();
	var code = $(this).attr('data-code');
	var _attrs = '';
	$.each(data, function( k, v ) {
		_attrs += ' ' + v.name + '="' + v.value + '"';
	});
    var scode = '[' + code + _attrs + '][/' + code + ']';
    $('#tspb_current_edit').html(scode);
	
	if($(this).hasClass('tspb-options-column')) {
		var _column = $('#tspb_current_edit').parent();
		var _colwidth = $(this).find('[name="sm"]').val();
		_column.attr('class', 'tspb-column col-xs-' + _colwidth);
	}
	
	$('#tspb_current_edit').attr('id', '');

	javascript:$.fancybox.close();
});
$(document).on('click', '.controls_section .ico-action .set-columns', function(e){
	e.preventDefault();
	var col_width = $(this).attr('data-colwidth');
	var cols = col_width.split(' ');
	var tpl = '';
	var _section = $(this).parents('.tspb-section');
	_section.find('.tspb-column').remove();
	$.each(cols, function( index, value ) {
		_tspb.addColumns(_section.find('.section_in'), value);
	});
});
// end section action btn

// column
$(document).on('click', '.controls_col .ico-action', function(e){
	e.preventDefault();
	var _column = $(this).parents('.controls_col').parent();
	if($(this).hasClass('action-delete')) _column.remove();
	if($(this).hasClass('action-add')) $(this).parent().find('.tspb-widgets').toggle();
	if($(this).hasClass('action-edit')) {
		var _optionsTag = $(this).parents('.tspb-controls').parent().find('> .scode-options');
		_optionsTag.attr('id', 'tspb_current_edit');
		_options = _tspb.getOptions(_optionsTag, 'tspb_column');
		var _columnOptionsTpl = $('.tspb-templates > .tspb-column-options-tpl').html();
		$('#tspb_options_wrapper').html(_columnOptionsTpl);

		$.each(_options, function( k, v ) {
		//	console.log(k, v);
			var form_ctr = $('#tspb_options_wrapper').find('[name="' + k + '"]');
			if(form_ctr.prop('tagName') == 'INPUT') form_ctr.val(v);
			if(form_ctr.prop('tagName') == 'SELECT') form_ctr.find('[value="' + v + '"]').attr('selected', 'selected');
			if(form_ctr.prop('tagName') == 'TEXTAREA') form_ctr.html(v);
		});
		$.fancybox({
			'href' : '#tspb_options_wrapper',
			maxWidth	: 800,
			width		: '70%',
			minWidth	: 500,
			helpers: { overlay: { locked: false } },
			beforeClose	: function () {
				_optionsTag.attr('id', '');
			}
		});
	}
});
//$(document).on('click', '.controls_col .tspb-options .action-update', function(e){
//	e.preventDefault();
//	var _column = $(this).parents('.tspb-controls').parent();
//	var _warp = $(this).parents('.tspb-options');
//		
//	_tspb.updateHtmlForm(_warp);
//	var _options = '[tspb_column';
//	_options += _tspb.getFormOptions(_warp);
//	_options += '][/tspb_column]';
//	_column.find('.scode-options').html(_options);
//	
//	var _colwidth = _warp.find('[name="sm"]').val();
//	_column.attr('data-width', _colwidth);
//	_column.attr('class', 'tspb-column col-xs-' + _colwidth);
//	
//	_warp.hide();
//});
$(document).on('click', '.controls_col .tspb-widgets .set-widget', function(e){
	e.preventDefault();
	var _column = $(this).parents('.controls_col').parent();
	_tspb.addWidget(_column.find('> .tspb-column-in'), $(this).attr('data-code'), $(this).attr('data-text'));
	$(this).parent().hide();
	_tspb.setSortable();
});
// row
$(document).on('click', '.controls_row .ico-action', function(e){
	e.preventDefault();
	var _row = $(this).parents('.tspb-controls').parent();
	if($(this).hasClass('action-delete')) _row.remove();
	if($(this).hasClass('action-clone')) _row.after(_row.clone());
	if($(this).hasClass('action-addcolumn')) _tspb.addColumns(_row, 12);
});
$(document).on('click', '.controls_row .ico-action .set-columns', function(e){
	e.preventDefault();
	var col_width = $(this).attr('data-colwidth');
	var cols = col_width.split(' ');
	var tpl = '';
	var _row = $(this).parents('.tspb-controls').parent();
	_row.find('.tspb-column').remove();
	$.each(cols, function( index, value ) {
		_tspb.addColumns(_row, value);
	});
});
// widget
$(document).on('click', '.controls_widget .ico-action', function(e){
	e.preventDefault();
	var _widget = $(this).parents('.tspb-widget');
	if($(this).hasClass('action-delete')) {
		_widget.remove();
	}
	if($(this).hasClass('action-edit')) {
		var _optionsTag = $(this).parents('.tspb-controls').parent().find('> .scode-options');
		_optionsTag.attr('id', 'tspb_current_edit');
		var _scode = _optionsTag.attr('data-code');
		_options = _tspb.getOptions(_optionsTag, _scode);
		var _widgetOptionsTpl = $('.tspb-templates > .tspb-widgets-options-tpl > .' + _scode + '-tpl').html();
		$('#tspb_options_wrapper').html(_widgetOptionsTpl);

		$.each(_options, function( k, v ) {
		//	console.log(k, v);
			var form_ctr = $('#tspb_options_wrapper').find('[name="' + k + '"]');
			if(form_ctr.prop('tagName') == 'INPUT') form_ctr.val(v);
			if(form_ctr.prop('tagName') == 'SELECT') form_ctr.find('[value="' + v + '"]').attr('selected', 'selected');
			if(form_ctr.prop('tagName') == 'TEXTAREA') form_ctr.html(v);
		});
		
		if($(this).hasClass('edit-tspb_textblock')) {
			_content = _tspb.getOptions(_optionsTag, _scode, true);
			$('#tspb_options_wrapper').find('[name="content"]').html(_content);
		}
		
		$('#tspb_options_wrapper').find('.tsp-imgfield').each(function(){
		    var date = new Date();
		    var now = date.getTime();
			var _eq = '_' + now + Math.random().toString().replace('.', '');
			$(this).find('.tsp-imgfield-input').attr('id', 'tspb_img' + _eq);
			$(this).find('.tsp-imgfield-open').attr('data-field_id', 'tspb_img' + _eq);
		});
		$.fancybox({
			href : '#tspb_options_wrapper',
			maxWidth	: 800,
			minWidth	: 500,
			width		: '70%',
			helpers: { overlay: { locked: false } },
			beforeClose	: function () {
				_optionsTag.attr('id', '');
			}
		});
	}
});
$(document).on('submit','.tspb-options-widget-form',function(e){
	e.preventDefault();
	var data = $(this).serializeArray();
	var code = $('#tspb_current_edit').attr('data-code');
	var _attrs = '';
	$.each(data, function( k, v ) {
		_attrs += ' ' + v.name + '="' + v.value + '"';
	});
    var scode = '[' + code + _attrs + '][/' + code + ']';
    $('#tspb_current_edit').html(scode);
	$('#tspb_current_edit').attr('id', '');
	javascript:$.fancybox.close();
});
$(document).on('submit','.tspb-options-widget-textblock-form',function(e){
	e.preventDefault();
	
	var _class = $(this).find('[name="class"]').val();
	var _content = $(this).find('[name="content"]').val();
	_content = _tspb.encodeEntities( _content );
	var code = $('#tspb_current_edit').attr('data-code');
    var scode = '[' + code + ' class=' + _class + ']' + _content + '[/' + code + ']';
    
    $('#tspb_current_edit').html(scode);
	$('#tspb_current_edit').attr('id', '');
	javascript:$.fancybox.close();
});
//$(document).on('click', '.controls_widget .tspb-options .action-update', function(e){
//	e.preventDefault();
//	var _warp = $(this).parents('.tspb-options');
//	var content = _warp.find('textarea').val();
//	_warp.find('textarea').html(content);
//	_warp.parents('.tspb-widget').find('.widget-content').html(content);
//	_warp.hide();
//});
//$(document).on('click', '.tspb-widget.tspb-widget-hook .controls_widget .tspb-options .action-update', function(e){
//	e.preventDefault();
//	var _warp = $(this).parents('.tspb-options');
//	var input_hook = _warp.find('[name*="hook"]');
//	input_hook.attr('value', input_hook.val());
//	var html = '[hook h="'+input_hook.val()+'"][/hook]'
//	_warp.parents('.tspb-widget').find('.widget-content').html(html);
//	_warp.hide();
//});






