$(document).ready(function()
{
    $('#search_block_top').on('click', function(e)
    {
        if ($(this).hasClass('tspquicksearch-open')){
            $(this).removeClass('tspquicksearch-open');
        }
        else {
            $(this).addClass('tspquicksearch-open');
            $('#search_query_top').focus();
        }

        e.stopPropagation();
    });

    $('#searchbox').on('click', function(e){
        e.stopPropagation();
    });

    $(document).on('click', function()
    {
        if ($('#search_block_top').hasClass('tspquicksearch-open')){
            $('#search_block_top').removeClass('tspquicksearch-open');
            $('.ac_results').hide();
        }
    });

});