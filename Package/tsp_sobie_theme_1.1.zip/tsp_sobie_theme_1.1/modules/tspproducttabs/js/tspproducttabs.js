$(document).ready(function(){
	$(".tsp-producttabs-block .nav-tabs").find("li").first().addClass("active");
	$(".tsp-producttabs-block .tab-content").find(".tab-pane").first().addClass("in active");
});
