<?php

include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../init.php');
include(dirname(__FILE__).'/tspproducttabs.php');

$tspproduct_tabs = new TSPProductTabs();
echo $tspproduct_tabs->_processAjaxCall();