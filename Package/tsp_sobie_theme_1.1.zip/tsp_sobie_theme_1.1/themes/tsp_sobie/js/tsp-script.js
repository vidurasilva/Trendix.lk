var TspScript = {
    init: function() {
        var that = this;
        that.setMenuActive();
        that.select2Style();
        that.parallaxInit();
        that.parallaxScollInit();
        that.setToolbar();
    },
    select2Style: function() {
    	var _els = $('.content_sortPagiBar select');
    	_els.each(function(){
    		var _selected = $(this).find('option:selected').text();
    		_selected = '<span><span>' + _selected + '</span><i class="fa fa-caret-down"></i></span>';
    		$(this).wrap('<div class="tsp-select">').before(_selected);
    	});
    	_els.on('change', function(){
    		var _selected = $(this).find('option:selected').text();
    		$(this).parent().find('> span span').text(_selected);
    	});
    },
	convertLinkToCompare: function (str) {
		str = str.split("?")[0];
		lastchar = str.substring(str.length - 1, str.length);
		if(lastchar === '/') {
			str = str.substring(0, str.length - 1);
		}
		if(str.search('index.php')) str = str.replace('/index.php', '');
		return str;
	},
	setMenuActive: function () {
		var that = this;
		var currentlink = jQuery(location).attr('href');
		currentlink = that.convertLinkToCompare(currentlink);
		
		var mainmenu = jQuery('#tsp_mainnav');
		
		mainmenu.find('li').removeClass('active');
		menulinks = mainmenu.find('li a');
		
		menulinks.each(function(){
			var menulink = that.convertLinkToCompare(jQuery(this).attr('href'));
			if(menulink === currentlink) {
				jQuery(this).parents('li[class*="level"]').addClass('active');
				return false;
			}
		});
	},
	parallaxInit: function () {
		$(window).scroll(function() {
		    var currentScroll_t = $(this).scrollTop();
		    var currentScroll_b = $(this).scrollTop() + $(window).outerHeight();
			$('.parallax').each(function(){
				var el_position_t = $(this).offset().top;;
				var el_position_b = $(this).offset().top; + $(this).outerHeight();
				if(currentScroll_b > el_position_t) {
					var p = (currentScroll_b - el_position_t) / 5;
					$(this).css({
							'background-position' : 'center -' + p + 'px',
							'background-attachment' : 'scroll'
						});
				}
			});
		});
	},
	parallaxScollInit: function () {
		$(window).on('scroll resize', function() {
			var w_t = $(window).scrollTop();
			$('.parallax-scroll').each(function(){
				var that = $(this);
				var e_t = that.offset().top;
				var translate = 0;
				if(w_t - e_t >= 0) {
					translate = w_t - e_t;
				} else {
					translate = 0;
				}
				that.css('overflow', 'hidden');
				that.find('.tsp-section-in').attr('style', 'transform: translateY(' + translate/2 + 'px)');
				//console.log(translate);
			});
		});
	},
	setToolbar: function () {
		$('#tsp_toolbar .scroll-top').click(function () {
			$('body,html').animate({
				scrollTop: 0
			}, 800);
			return false;
		});
	},
};

//$(window).on('scroll resize', function() {
//	var w_t = $(window).scrollTop();
//	var w_h = $(window).height();
//	var wb_t = w_t + w_h;
//	$('.parallax-scroll').each(function(){
//		var that = $(this);
//		var e_t = that.offset().top;
//		var e_h = that.outerHeight();
//		var eb_t = e_t + e_h;
//		var translate = 0;
//		if(w_t - e_t >= 0) {
//			translate = w_t - e_t;
//		}
//		if(w_t - e_t <= 0) {
//			translate = wb_t - eb_t;
//		}
//		if(w_t - e_t <= 0 && wb_t - eb_t >= 0) {
//			translate = 0;
//		}
//		
//		that.css('overflow', 'hidden');
//		that.find('.tsp-section-in').attr('style', 'transform: translateY(' + translate/1.5 + 'px)');
//		console.log(translate);
//	});
//});



function countCSSRules() {
    var results = '',
        log = '';
    if (!document.styleSheets) {
        return;
    }
    for (var i = 0; i < document.styleSheets.length; i++) {
        var sheet = document.styleSheets[i];
        var count = 0;
        if (sheet && sheet.cssRules) {
            for (var j = 0, l = sheet.cssRules.length; j < l; j++) {
                if (!sheet.cssRules[j].selectorText) {
                    if (sheet.cssRules[j].cssRules) {
                        for (var m = 0, n = sheet.cssRules[j].cssRules.length; m < n; m++) {
                            if(sheet.cssRules[j].cssRules[m].selectorText) {
                                count += sheet.cssRules[j].cssRules[m].selectorText.split(',').length;
                            }
                        }
                    }
                }
                else {
                    count += sheet.cssRules[j].selectorText.split(',').length;
                }
            }
 
            log += '\nFile: ' + (sheet.href ? sheet.href : 'inline <style> tag');
            log += '\nRules: ' + sheet.cssRules.length;
            log += '\nSelectors: ' + count;
            log += '\n--------------------------';
            if (count >= 4096) {
                results += '\n********************************\nWARNING:\n There are ' + count + ' CSS rules in the stylesheet ' + sheet.href + ' - IE will ignore the last ' + (count - 4096) + ' rules!\n';
            }
        }
    }
    console.log(log);
    console.log(results);
};
//countCSSRules();
$(document).ready( function(){
	TspScript.init();
	if (typeof TSP_TOOLTIP != 'undefined' && TSP_TOOLTIP) {
		$("[data-toggle='tooltip']").tooltip({
			container: 'body'
		});
	}
	if (typeof KEEP_MENU != 'undefined' && KEEP_MENU) {
		if($('#tsp_menu').length){
			$('#tsp_menu').css('width', $('#tsp_header').innerWidth());
			
		    var previousScroll = 0,
		        headerOrgOffset = $('#tsp_menu').offset().top + $('#tsp_menu').outerHeight();
		    
		    $(window).scroll(function() {
		        var currentScroll = $(this).scrollTop();
		        if(currentScroll > headerOrgOffset) {
		        	if(!$('#tsp_menu_clone').length) $('#tsp_menu').after('<div id="tsp_menu_clone" style="height: ' + $('#tsp_menu').outerHeight() + 'px"></div>');
		        	$('#tsp_menu').addClass('keep-menu');
		            $('#tsp_menu').stop(true, true).addClass('keep-menu-show').fadeIn();
		        } else {
					$('#tsp_menu_clone').remove();
		        	$('#tsp_menu').removeClass('keep-menu');
					$('#tsp_menu').fadeIn(0);
		        }
		        previousScroll = currentScroll;
		    });
		}
	}
	if($('#tsp_right').length) {
		$('#tsp_mommenu .btn2.rightsidebar').css('display', 'inline-block').on('click', function(){
			if($('#tsp_right').hasClass('active')){
				$(this).find('.overlay').fadeOut(250);
				$('#tsp_right').removeClass('active');
				$('body').removeClass('show-sidebar');
			} else {
				$('#tsp_right').addClass('active');
				$(this).find('.overlay').fadeIn(250);
				$('body').addClass('show-sidebar');
			}
		});
	}
	if($('#tsp_left').length) {
		$('#tsp_mommenu .btn2.leftsidebar').css('display', 'inline-block').on('click', function(){
			if($('#tsp_left').hasClass('active')){
				$(this).find('.overlay').fadeOut(250);
				$('#tsp_left').removeClass('active');
				$('body').removeClass('show-sidebar');
			} else {
				$('#tsp_left').addClass('active');
				$(this).find('.overlay').fadeIn();
				$('body').addClass('show-sidebar');
			}
		});
	}
});

$.ajaxPrefilter(function( options, originalOptions, jqXHR ) {
	if(!originalOptions.url.match(/tspquicksearch|blocklayered/i)) {
		$('.ajaxloading').fadeIn();
	}
});

$(document).on('ajaxStop', function(){
	$('.ajaxloading').fadeOut();
});
function setAddtocartBtn() {
	$('.products-grid .item .item-inner, .product_list.grid .block-product-inner').each(function(){
		if($(this).outerWidth() < 270){
			$(this).find('.btn-addtocart span').hide();
		} else {
			$(this).find('.btn-addtocart span').show();
		}
	});
}
//$(window).on('load resize', setAddtocartBtn);
$(document).on('ajaxComplete', setAddtocartBtn);








