$(document).ready( function(){
	$("#tsp_cpanel").each( function(){
		var wrap = this;
		$("#tsp_config_btn",this).click( function(){
			if( $(wrap).hasClass("active") ){
				$(wrap).removeClass("active");
				$(wrap).stop().animate({
					'right': - $(wrap).outerWidth()
				}, 600); 
			}else{
			  	$(wrap).addClass("active");
			  	$(wrap).stop().animate({
					'right':'0px',
				}, 600);
			}
		} );
	} );

		// bg color
		$('[name$="BODYCOLOR"]').on('change', function (){
			$('body').css({
				'background-color' : $(this).val()
			});
		});
		
		// bg image
		$('.tsp-patterns .radio_img_group label').on('click', function(){
			$('body').css('background-image', 'url("'+ img_dir + 'patterns/' + $(this).find('input').val() + '")');
		});
		// layout type
		$('[name*="WRAPPERWIDTH"]').on('change', function (){
			if($(this).val() >= 1200) {
				$("#tsp_wrapper").css('max-width', $(this).val()  + 'px');
			} else {
				$(this).val(1200)
				$("#tsp_wrapper").css('max-width', 1200  + 'px');
			}
		});
		
		// fontsize
		$('[name*="FONTSIZE"]').on('change', function (){
			$('body').css('font-size', $(this).val());
		});
		
});